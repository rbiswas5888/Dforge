(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=`1.0.0`;function t(e=`node`){return`${e}_${Math.random().toString(36).substring(2,9)}_${Date.now().toString(36)}`}function n(){return[{id:`tokens_colors`,name:`Colors`,tokens:[{id:`token_brand_primary`,name:`Brand / Primary`,type:`color`,value:`#3b82f6`},{id:`token_brand_accent`,name:`Brand / Accent`,type:`color`,value:`#8b5cf6`},{id:`token_bg_main`,name:`Background / Main`,type:`color`,value:`#0f172a`},{id:`token_bg_surface`,name:`Background / Surface`,type:`color`,value:`#1e293b`},{id:`token_bg_elevated`,name:`Background / Elevated`,type:`color`,value:`#334155`},{id:`token_text_primary`,name:`Text / Primary`,type:`color`,value:`#f8fafc`},{id:`token_text_muted`,name:`Text / Muted`,type:`color`,value:`#94a3b8`},{id:`token_border_subtle`,name:`Border / Subtle`,type:`color`,value:`#334155`},{id:`token_success`,name:`Status / Success`,type:`color`,value:`#10b981`},{id:`token_danger`,name:`Status / Danger`,type:`color`,value:`#ef4444`}]},{id:`tokens_spacing`,name:`Spacing`,tokens:[{id:`token_space_xs`,name:`Space / XS`,type:`dimension`,value:4},{id:`token_space_sm`,name:`Space / SM`,type:`dimension`,value:8},{id:`token_space_md`,name:`Space / MD`,type:`dimension`,value:16},{id:`token_space_lg`,name:`Space / LG`,type:`dimension`,value:24},{id:`token_space_xl`,name:`Space / XL`,type:`dimension`,value:32}]},{id:`tokens_radius`,name:`Corner Radius`,tokens:[{id:`token_radius_sm`,name:`Radius / SM`,type:`dimension`,value:6},{id:`token_radius_md`,name:`Radius / MD`,type:`dimension`,value:12},{id:`token_radius_lg`,name:`Radius / LG`,type:`dimension`,value:20},{id:`token_radius_full`,name:`Radius / Full`,type:`dimension`,value:9999}]}]}function r(e,n={}){let r={id:n.id||t(e),type:e,name:n.name||e.charAt(0).toUpperCase()+e.slice(1),parentId:n.parentId||null,childIds:n.childIds||[],visible:n.visible===void 0||n.visible,locked:n.locked!==void 0&&n.locked,opacity:n.opacity===void 0?1:n.opacity,componentId:n.componentId||null,variantId:n.variantId||null,booleanOperation:n.booleanOperation||null,transform:{x:0,y:0,width:100,height:100,rotation:0,scaleX:1,scaleY:1,...n.transform||{}},layout:{mode:`none`,paddingTop:0,paddingRight:0,paddingBottom:0,paddingLeft:0,gap:0,alignItems:`start`,justifyContent:`start`,sizingHorizontal:`fixed`,sizingVertical:`fixed`,...n.layout||{}},style:{fills:n.style?.fills||[{type:`solid`,color:`#334155`,opacity:1}],strokes:n.style?.strokes||[],cornerRadius:n.style?.cornerRadius===void 0?0:n.style.cornerRadius,shadows:n.style?.shadows||[],...n.style||{}},interactions:n.interactions||[],tokenBindings:n.tokenBindings||{},semanticTag:n.semanticTag||(e===`frame`?`div`:e===`text`?`p`:`div`),accessibilityLabel:n.accessibilityLabel||``,metadata:n.metadata||{},text:n.text?{...n.text}:null};return e===`frame`?(r.transform.width=n.transform?.width||360,r.transform.height=n.transform?.height||240,r.style.fills=n.style?.fills||[{type:`solid`,color:`#1e293b`,opacity:1}],r.style.cornerRadius=n.style?.cornerRadius===void 0?12:n.style.cornerRadius):e===`text`?(r.transform.width=n.transform?.width||180,r.transform.height=n.transform?.height||32,r.style.fills=[],r.text={content:n.text?.content||`Double click to edit`,fontFamily:n.text?.fontFamily||`Inter, -apple-system, sans-serif`,fontSize:n.text?.fontSize||16,fontWeight:n.text?.fontWeight||`400`,lineHeight:n.text?.lineHeight||1.4,letterSpacing:n.text?.letterSpacing||0,textAlign:n.text?.textAlign||`left`,color:n.text?.color||`#f8fafc`,...n.text||{}}):e===`rectangle`?(r.style.fills=n.style?.fills||[{type:`solid`,color:`#3b82f6`,opacity:1}],r.style.cornerRadius=n.style?.cornerRadius===void 0?8:n.style.cornerRadius):e===`ellipse`?(r.style.fills=n.style?.fills||[{type:`solid`,color:`#8b5cf6`,opacity:1}],r.style.cornerRadius=9999):e===`line`?(r.style.strokes=n.style?.strokes||[{color:`#38bdf8`,width:2,align:`center`,style:`solid`}],r.style.fills=[],r.transform.height=2):e===`polygon`||e===`star`?(r.style.fills=n.style?.fills||[{type:`solid`,color:`#f59e0b`,opacity:1}],r.style.cornerRadius=0):e===`image`?(r.style.fills=n.style?.fills||[{type:`image`,url:n.imageUrl||`https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80`,opacity:1}],r.style.cornerRadius=n.style?.cornerRadius===void 0?8:n.style.cornerRadius,r.image={fit:`cover`,url:n.imageUrl||`https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80`}):e===`group`?(r.type=`group`,r.name=n.name||`Group`,r.style.fills=[]):e===`button`&&(r.type=`frame`,r.name=n.name||`Button`,r.semanticTag=`button`,r.transform.width=n.transform?.width||140,r.transform.height=n.transform?.height||44,r.layout.mode=`stack-horizontal`,r.layout.alignItems=`center`,r.layout.justifyContent=`center`,r.layout.gap=8,r.layout.paddingLeft=16,r.layout.paddingRight=16,r.style.fills=n.style?.fills||[{type:`solid`,color:`#3b82f6`,opacity:1}],r.style.cornerRadius=n.style?.cornerRadius===void 0?8:n.style.cornerRadius),r}function i(e=`Page 1`,n=`/`){return{id:t(`page`),name:e,route:n,background:`#090d16`,nodes:{},rootIds:[],seo:{title:`${e} | DesignForge AI Project`,description:`Built with DesignForge AI`}}}function a(a=`Fintech Experience Platform`){let o={schemaVersion:e,id:t(`proj`),name:a,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),appVersion:`1.0.0`,exportProfile:{framework:`react-vite-cssmodules`,typescript:!0},pages:[],components:[],tokens:n(),assets:[]},s=i(`Dashboard`,`/`),c=r(`frame`,{name:`Desktop App Shell (1440px)`,transform:{x:80,y:80,width:1200,height:760},style:{fills:[{type:`solid`,color:`#0f172a`,opacity:1}],strokes:[{color:`#1e293b`,width:1,align:`inside`}],cornerRadius:16,shadows:[{x:0,y:24,blur:48,spread:0,color:`rgba(0,0,0,0.5)`,inner:!1}]},layout:{mode:`stack-horizontal`,alignItems:`stretch`},semanticTag:`main`}),l=r(`frame`,{parentId:c.id,name:`Sidebar Nav`,transform:{x:0,y:0,width:240,height:760},style:{fills:[{type:`solid`,color:`#111827`,opacity:1}],strokes:[{color:`#1f2937`,width:1,align:`inside`}],cornerRadius:0},layout:{mode:`stack-vertical`,paddingTop:24,paddingLeft:20,paddingRight:20,paddingBottom:24,gap:20},semanticTag:`nav`}),u=r(`text`,{parentId:l.id,name:`App Logo`,transform:{x:0,y:0,width:200,height:28},text:{content:`⚡ ForgePay AI`,fontSize:18,fontWeight:`700`,color:`#38bdf8`}}),d=r(`frame`,{parentId:l.id,name:`Nav / Overview`,transform:{x:0,y:0,width:200,height:40},style:{fills:[{type:`solid`,color:`#1e293b`,opacity:1}],cornerRadius:8},layout:{mode:`stack-horizontal`,alignItems:`center`,paddingLeft:12,paddingRight:12},semanticTag:`a`}),f=r(`text`,{parentId:d.id,name:`Nav Label`,transform:{x:0,y:0,width:160,height:20},text:{content:`📊 Overview`,fontSize:14,fontWeight:`600`,color:`#f8fafc`}});d.childIds.push(f.id);let p=r(`frame`,{parentId:l.id,name:`Nav / Transactions`,transform:{x:0,y:0,width:200,height:40},style:{fills:[],cornerRadius:8},layout:{mode:`stack-horizontal`,alignItems:`center`,paddingLeft:12,paddingRight:12},semanticTag:`a`}),m=r(`text`,{parentId:p.id,name:`Nav Label`,transform:{x:0,y:0,width:160,height:20},text:{content:`💳 Cards & Accounts`,fontSize:14,fontWeight:`500`,color:`#94a3b8`}});p.childIds.push(m.id);let h=r(`frame`,{parentId:l.id,name:`Nav / Analytics`,transform:{x:0,y:0,width:200,height:40},style:{fills:[],cornerRadius:8},layout:{mode:`stack-horizontal`,alignItems:`center`,paddingLeft:12,paddingRight:12},semanticTag:`a`}),g=r(`text`,{parentId:h.id,name:`Nav Label`,transform:{x:0,y:0,width:160,height:20},text:{content:`📈 AI Insights`,fontSize:14,fontWeight:`500`,color:`#94a3b8`}});h.childIds.push(g.id),l.childIds.push(u.id,d.id,p.id,h.id);let _=r(`frame`,{parentId:c.id,name:`Dashboard Body`,transform:{x:240,y:0,width:960,height:760},style:{fills:[{type:`solid`,color:`#090d16`,opacity:1}]},layout:{mode:`stack-vertical`,paddingTop:32,paddingLeft:36,paddingRight:36,paddingBottom:32,gap:28},semanticTag:`section`}),v=r(`frame`,{parentId:_.id,name:`Header Bar`,transform:{x:0,y:0,width:888,height:48},style:{fills:[]},layout:{mode:`stack-horizontal`,alignItems:`center`,justifyContent:`space-between`}}),y=r(`text`,{parentId:v.id,name:`Header Title`,transform:{x:0,y:0,width:340,height:32},text:{content:`Executive Treasury Overview`,fontSize:24,fontWeight:`700`,color:`#ffffff`}}),b=r(`frame`,{parentId:v.id,name:`Send Funds CTA`,transform:{x:0,y:0,width:140,height:40},style:{fills:[{type:`solid`,color:`#2563eb`,opacity:1}],cornerRadius:8,shadows:[{x:0,y:4,blur:12,color:`rgba(37, 99, 235, 0.4)`,inner:!1}]},layout:{mode:`stack-horizontal`,alignItems:`center`,justifyContent:`center`},semanticTag:`button`}),x=r(`text`,{parentId:b.id,name:`Button Text`,transform:{x:0,y:0,width:110,height:20},text:{content:`+ Transfer Funds`,fontSize:13,fontWeight:`600`,color:`#ffffff`,textAlign:`center`}});b.childIds.push(x.id),v.childIds.push(y.id,b.id);let S=r(`frame`,{parentId:_.id,name:`Stats Row`,transform:{x:0,y:0,width:888,height:140},style:{fills:[]},layout:{mode:`stack-horizontal`,gap:20,alignItems:`stretch`}}),C=r(`frame`,{parentId:S.id,name:`Metric / Total Balance`,transform:{x:0,y:0,width:282,height:140},style:{fills:[{type:`solid`,color:`#161e2e`,opacity:1}],strokes:[{color:`#26334d`,width:1,align:`inside`}],cornerRadius:12},layout:{mode:`stack-vertical`,paddingTop:20,paddingLeft:20,paddingRight:20,paddingBottom:20,gap:8}}),w=r(`text`,{parentId:C.id,name:`Label`,transform:{x:0,y:0,width:220,height:18},text:{content:`Total Portfolio Balance`,fontSize:13,fontWeight:`500`,color:`#94a3b8`}}),T=r(`text`,{parentId:C.id,name:`Value`,transform:{x:0,y:0,width:220,height:36},text:{content:`$2,845,920.40`,fontSize:26,fontWeight:`800`,color:`#ffffff`}}),E=r(`text`,{parentId:C.id,name:`Trend`,transform:{x:0,y:0,width:220,height:18},text:{content:`▲ +14.2% from last month`,fontSize:12,fontWeight:`600`,color:`#10b981`}});C.childIds.push(w.id,T.id,E.id);let D=r(`frame`,{parentId:S.id,name:`Metric / 30d Inflow`,transform:{x:0,y:0,width:282,height:140},style:{fills:[{type:`solid`,color:`#161e2e`,opacity:1}],strokes:[{color:`#26334d`,width:1,align:`inside`}],cornerRadius:12},layout:{mode:`stack-vertical`,paddingTop:20,paddingLeft:20,paddingRight:20,paddingBottom:20,gap:8}}),O=r(`text`,{parentId:D.id,name:`Label`,transform:{x:0,y:0,width:220,height:18},text:{content:`Monthly Global Volume`,fontSize:13,fontWeight:`500`,color:`#94a3b8`}}),k=r(`text`,{parentId:D.id,name:`Value`,transform:{x:0,y:0,width:220,height:36},text:{content:`$840,119.00`,fontSize:26,fontWeight:`800`,color:`#38bdf8`}}),A=r(`text`,{parentId:D.id,name:`Trend`,transform:{x:0,y:0,width:220,height:18},text:{content:`⚡ 99.98% instant settlement`,fontSize:12,fontWeight:`500`,color:`#94a3b8`}});D.childIds.push(O.id,k.id,A.id);let j=r(`frame`,{parentId:S.id,name:`Metric / Vault Protection`,transform:{x:0,y:0,width:282,height:140},style:{fills:[{type:`solid`,color:`#161e2e`,opacity:1}],strokes:[{color:`#26334d`,width:1,align:`inside`}],cornerRadius:12},layout:{mode:`stack-vertical`,paddingTop:20,paddingLeft:20,paddingRight:20,paddingBottom:20,gap:8}}),M=r(`text`,{parentId:j.id,name:`Label`,transform:{x:0,y:0,width:220,height:18},text:{content:`Multi-Sig Vault Health`,fontSize:13,fontWeight:`500`,color:`#94a3b8`}}),N=r(`text`,{parentId:j.id,name:`Value`,transform:{x:0,y:0,width:220,height:36},text:{content:`100% Secure`,fontSize:26,fontWeight:`800`,color:`#10b981`}}),P=r(`text`,{parentId:j.id,name:`Trend`,transform:{x:0,y:0,width:220,height:18},text:{content:`🔒 Hardware KMS Enclave active`,fontSize:12,fontWeight:`500`,color:`#94a3b8`}});j.childIds.push(M.id,N.id,P.id),S.childIds.push(C.id,D.id,j.id);let F=r(`frame`,{parentId:_.id,name:`Transactions Card`,transform:{x:0,y:0,width:888,height:420},style:{fills:[{type:`solid`,color:`#111827`,opacity:1}],strokes:[{color:`#1f2937`,width:1,align:`inside`}],cornerRadius:12},layout:{mode:`stack-vertical`,paddingTop:24,paddingLeft:24,paddingRight:24,paddingBottom:24,gap:16}}),I=r(`text`,{parentId:F.id,name:`Section Title`,transform:{x:0,y:0,width:300,height:24},text:{content:`Recent Enterprise Transactions`,fontSize:16,fontWeight:`700`,color:`#ffffff`}});function L(e,t,n,i,a,o){let s=r(`frame`,{parentId:F.id,name:`Row / ${t}`,transform:{x:0,y:0,width:840,height:52},style:{fills:[{type:`solid`,color:`#161f30`,opacity:1}],cornerRadius:8},layout:{mode:`stack-horizontal`,alignItems:`center`,justifyContent:`space-between`,paddingLeft:16,paddingRight:16}}),c=r(`frame`,{parentId:s.id,name:`Col Left`,transform:{x:0,y:0,width:360,height:36},style:{fills:[]},layout:{mode:`stack-vertical`,gap:2}}),l=r(`text`,{parentId:c.id,name:`Title`,transform:{x:0,y:0,width:300,height:18},text:{content:t,fontSize:14,fontWeight:`600`,color:`#f8fafc`}}),u=r(`text`,{parentId:c.id,name:`Subtitle`,transform:{x:0,y:0,width:300,height:14},text:{content:n,fontSize:12,fontWeight:`400`,color:`#64748b`}});c.childIds.push(l.id,u.id);let d=r(`frame`,{parentId:s.id,name:`Col Right`,transform:{x:0,y:0,width:240,height:36},style:{fills:[]},layout:{mode:`stack-horizontal`,alignItems:`center`,justifyContent:`end`,gap:16}}),f=r(`text`,{parentId:d.id,name:`Amount`,transform:{x:0,y:0,width:140,height:20},text:{content:i,fontSize:15,fontWeight:`700`,color:`#ffffff`,textAlign:`right`}}),p=r(`frame`,{parentId:d.id,name:`Status Badge`,transform:{x:0,y:0,width:78,height:26},style:{fills:[{type:`solid`,color:a,opacity:.15}],cornerRadius:13},layout:{mode:`stack-horizontal`,alignItems:`center`,justifyContent:`center`}}),m=r(`text`,{parentId:p.id,name:`Badge Text`,transform:{x:0,y:0,width:70,height:14},text:{content:o,fontSize:11,fontWeight:`600`,color:a,textAlign:`center`}});return p.childIds.push(m.id),d.childIds.push(f.id,p.id),s.childIds.push(c.id,d.id),[s,c,l,u,d,f,p,m]}let R=L(1,`Anthropic PBC Cloud API Settlement`,`Invoice #INV-2026-881 • ACH Transfer`,`-$14,250.00`,`#10b981`,`Completed`),z=L(2,`Stripe Global Merchant Payout`,`Batch #B-9921 • Automated Settlement`,`+$124,500.00`,`#10b981`,`Completed`),B=L(3,`Google Cloud EMEA Infrastructure`,`Compute & BigQuery storage reservation`,`-$8,490.20`,`#f59e0b`,`Pending`),V=L(4,`Sequoia Capital Seed Disbursement`,`Treasury wire receipt`,`+$500,000.00`,`#10b981`,`Completed`);F.childIds.push(I.id,R[0].id,z[0].id,B[0].id,V[0].id),_.childIds.push(v.id,S.id,F.id),c.childIds.push(l.id,_.id);let H=[c,l,u,d,f,p,m,h,g,_,v,y,b,x,S,C,w,T,E,D,O,k,A,j,M,N,P,F,I,...R,...z,...B,...V];for(let e of H)s.nodes[e.id]=e;s.rootIds.push(c.id);let U=r(`frame`,{name:`Mobile Screen (375px)`,transform:{x:1340,y:80,width:375,height:760},style:{fills:[{type:`solid`,color:`#090d16`,opacity:1}],strokes:[{color:`#334155`,width:2,align:`inside`}],cornerRadius:36,shadows:[{x:0,y:20,blur:40,color:`rgba(0,0,0,0.6)`,inner:!1}]},layout:{mode:`stack-vertical`,paddingTop:36,paddingLeft:20,paddingRight:20,paddingBottom:24,gap:20}}),W=r(`text`,{parentId:U.id,name:`Mobile App Title`,transform:{x:0,y:0,width:335,height:28},text:{content:`⚡ ForgePay Mobile`,fontSize:18,fontWeight:`700`,color:`#ffffff`}}),G=r(`frame`,{parentId:U.id,name:`Balance Card Mobile`,transform:{x:0,y:0,width:335,height:160},style:{fills:[{type:`solid`,color:`#2563eb`,opacity:1}],cornerRadius:16,shadows:[{x:0,y:8,blur:24,color:`rgba(37,99,235,0.4)`,inner:!1}]},layout:{mode:`stack-vertical`,paddingTop:20,paddingLeft:20,paddingRight:20,paddingBottom:20,gap:8}}),K=r(`text`,{parentId:G.id,name:`Card Label`,transform:{x:0,y:0,width:295,height:16},text:{content:`Total Portfolio Balance`,fontSize:13,fontWeight:`500`,color:`#bfdbfe`}}),q=r(`text`,{parentId:G.id,name:`Card Amount`,transform:{x:0,y:0,width:295,height:36},text:{content:`$2,845,920.40`,fontSize:26,fontWeight:`800`,color:`#ffffff`}}),J=r(`text`,{parentId:G.id,name:`Card Sub`,transform:{x:0,y:0,width:295,height:16},text:{content:`●●●● 8821  •  Exp 09/29`,fontSize:12,fontWeight:`500`,color:`#93c5fd`}});G.childIds.push(K.id,q.id,J.id);let Y=r(`frame`,{parentId:U.id,name:`Quick Action Row`,transform:{x:0,y:0,width:335,height:50},style:{fills:[]},layout:{mode:`stack-horizontal`,gap:12,alignItems:`stretch`}}),X=r(`frame`,{parentId:Y.id,name:`Btn Send`,transform:{x:0,y:0,width:161,height:50},style:{fills:[{type:`solid`,color:`#1e293b`,opacity:1}],cornerRadius:10},layout:{mode:`stack-horizontal`,alignItems:`center`,justifyContent:`center`},semanticTag:`button`}),Z=r(`text`,{parentId:X.id,name:`Send Txt`,transform:{x:0,y:0,width:120,height:20},text:{content:`↑ Send`,fontSize:14,fontWeight:`600`,color:`#ffffff`,textAlign:`center`}});X.childIds.push(Z.id);let Q=r(`frame`,{parentId:Y.id,name:`Btn Receive`,transform:{x:0,y:0,width:161,height:50},style:{fills:[{type:`solid`,color:`#1e293b`,opacity:1}],cornerRadius:10},layout:{mode:`stack-horizontal`,alignItems:`center`,justifyContent:`center`},semanticTag:`button`}),$=r(`text`,{parentId:Q.id,name:`Rec Txt`,transform:{x:0,y:0,width:120,height:20},text:{content:`↓ Receive`,fontSize:14,fontWeight:`600`,color:`#ffffff`,textAlign:`center`}});Q.childIds.push($.id),Y.childIds.push(X.id,Q.id),U.childIds.push(W.id,G.id,Y.id);let ee=[U,W,G,K,q,J,Y,X,Z,Q,$];for(let e of ee)s.nodes[e.id]=e;return s.rootIds.push(U.id),o.pages.push(s),o}function o(e,t=`New Page`,n=null){let r=e.pages.length+1,a=t||`Page ${r}`,o=i(a,n||`/${a.toLowerCase().replace(/\s+/g,`-`)}`);return e.pages.push(o),o}function s(e,n){let r=e.pages.find(e=>e.id===n);if(!r)return null;let i=JSON.parse(JSON.stringify(r));return i.id=t(`page`),i.name=`${r.name} (Copy)`,i.route=`${r.route}-copy`,e.pages.push(i),i}function c(e,t){if(e.pages.length<=1)return!1;let n=e.pages.findIndex(e=>e.id===t);return n!==-1&&(e.pages.splice(n,1),!0)}function l(e,t,n){let r=e.pages.find(e=>e.id===t);return r&&n?.trim()?(r.name=n.trim(),!0):!1}function u(e,n){e.comments||=[];let r={id:t(`comment`),x:n.x||100,y:n.y||100,pageId:n.pageId||e.pages[0]?.id,author:n.author||`Product Designer`,text:n.text||`Review note`,createdAt:new Date().toISOString(),resolved:!1};return e.comments.push(r),r}function d(e,t){if(!e.comments)return!1;let n=e.comments.find(e=>e.id===t);return n?(n.resolved=!n.resolved,!0):!1}function f(e,t,n=new Map){if(n.has(t))return n.get(t);let r=e.nodes[t];if(!r||!r.transform){let e={x:0,y:0,width:0,height:0};return n.set(t,e),e}let i=r.transform.x,a=r.transform.y;if(r.parentId&&e.nodes[r.parentId]){let t=f(e,r.parentId,n),o=e.nodes[r.parentId];if(o.layout&&o.layout.mode!==`none`){let n=p(o,r,e);i=t.x+n.x,a=t.y+n.y}else i=t.x+r.transform.x,a=t.y+r.transform.y}let o={x:i,y:a,width:r.transform.width,height:r.transform.height};return n.set(t,o),o}function p(e,t,n){let r=e.layout.mode,i=e.layout.paddingTop||0,a=e.layout.paddingLeft||0,o=e.layout.paddingRight||0,s=e.layout.paddingBottom||0,c=e.layout.gap||0,l=e.layout.alignItems||`start`,u=e.layout.justifyContent||`start`,d=e.childIds.indexOf(t.id);if(d===-1)return{x:t.transform.x,y:t.transform.y};if(r===`stack-horizontal`){let r=a;for(let t=0;t<d;t++){let i=n.nodes[e.childIds[t]];i&&i.transform&&(r+=i.transform.width+c)}let f=e.transform.height-i-s,p=i;if(l===`center`?p=i+Math.max(0,(f-t.transform.height)/2):l===`end`&&(p=e.transform.height-s-t.transform.height),u===`space-between`&&e.childIds.length>1){let t=0;e.childIds.forEach(e=>{let r=n.nodes[e];r?.transform&&(t+=r.transform.width)});let r=Math.max(c,(e.transform.width-a-o-t)/(e.childIds.length-1)),i=a;for(let t=0;t<d;t++){let a=n.nodes[e.childIds[t]];a?.transform&&(i+=a.transform.width+r)}return{x:i,y:p}}return{x:r,y:p}}if(r===`stack-vertical`){let r=i;for(let t=0;t<d;t++){let i=n.nodes[e.childIds[t]];i&&i.transform&&(r+=i.transform.height+c)}let s=e.transform.width-a-o,u=a;return l===`center`?u=a+Math.max(0,(s-t.transform.width)/2):l===`end`&&(u=e.transform.width-o-t.transform.width),{x:u,y:r}}return{x:t.transform.x,y:t.transform.y}}function m(e,t){if(!t||t.length===0)return null;let n=1/0,r=1/0,i=-1/0,a=-1/0;for(let o of t){let t=f(e,o);t&&(n=Math.min(n,t.x),r=Math.min(r,t.y),i=Math.max(i,t.x+t.width),a=Math.max(a,t.y+t.height))}return n===1/0?null:{x:n,y:r,width:i-n,height:a-r}}function h(e,t,n=[],r=6){let i=[],a=null,o=null,s=r,c=r,l=[t.x,t.x+t.width/2,t.x+t.width],u=[t.y,t.y+t.height/2,t.y+t.height];for(let r of e.rootIds){if(n.includes(r))continue;let d=f(e,r);if(!d)continue;let p=[d.x,d.x+d.width/2,d.x+d.width],m=[d.y,d.y+d.height/2,d.y+d.height];for(let e of l)for(let n of p){let r=Math.abs(e-n);r<s&&(s=r,a=n-(e-t.x),i.push({type:`vertical`,x:n}))}for(let e of u)for(let n of m){let r=Math.abs(e-n);r<c&&(c=r,o=n-(e-t.y),i.push({type:`horizontal`,y:n}))}}return{snapX:a,snapY:o,guides:i}}var g=class{constructor({mass:e=1,stiffness:t=100,damping:n=15}={}){this.mass=Math.max(.001,e),this.stiffness=Math.max(.001,t),this.damping=Math.max(0,n),this.w0=Math.sqrt(this.stiffness/this.mass),this.zeta=this.damping/(2*Math.sqrt(this.stiffness*this.mass))}evaluate(e,t,n=0){if(e<=0)return{position:t,velocity:n};let{w0:r,zeta:i}=this;if(Math.abs(i-1)<1e-4){let i=t,a=n+r*t,o=Math.exp(-r*e);return{position:o*(i+a*e),velocity:o*(a-r*(i+a*e))}}if(i<1){let a=r*Math.sqrt(1-i*i),o=t,s=(n+i*r*t)/a,c=Math.exp(-i*r*e),l=Math.cos(a*e),u=Math.sin(a*e);return{position:c*(o*l+s*u),velocity:c*(-i*r*(o*l+s*u)+a*(-o*u+s*l))}}{let a=Math.sqrt(i*i-1),o=-r*(i-a),s=-r*(i+a),c=(n-o*t)/(s-o),l=t-c,u=Math.exp(o*e),d=Math.exp(s*e);return{position:l*u+c*d,velocity:l*o*u+c*s*d}}}solve(e){if(e<=0)return 0;let{position:t}=this.evaluate(e,-1,0);return 1+t}calculateRubberBandResistance(e,t=.55){let n=Math.sign(e),r=Math.abs(e);return-n*t*r**1.5}},_=class{constructor(e=.0035){this.friction=e,this.history=[],this.windowMs=50}addPoint(e,t,n=Date.now()){this.history.push({x:e,y:t,timestamp:n});let r=n-this.windowMs;for(;this.history.length>2&&this.history[0].timestamp<r;)this.history.shift()}computeReleaseVelocity(){if(this.history.length<2)return{vx:0,vy:0};let e=this.history[0],t=this.history[this.history.length-1],n=(t.timestamp-e.timestamp)/1e3;return n<=0?{vx:0,vy:0}:{vx:(t.x-e.x)/n,vy:(t.y-e.y)/n}}evaluateInertialPosition(e,t,n){let r=this.friction*1e3,i=Math.exp(-r*n);return{position:e+t/r*(1-i),velocity:t*i}}},v=class{constructor(e={}){this.globalVariables={...e},this.componentStates={},this.history=[]}setVariable(e,t){this.globalVariables[e]=t}getVariable(e){return this.globalVariables[e]}evaluatePredicate(e){if(!e||e.trim()===``||e===`true`)return!0;try{let t={...this.globalVariables},n=Object.keys(t),r=Object.values(t);return!!Function(...n,`return Boolean(${e});`)(...r)}catch{return!1}}executeMutation(e){if(e&&e.trim()!==``)try{let t=e.trim().match(/^([a-zA-Z0-9_]+)\s*(\+=|-=|\*=|\/=|=)\s*(.+)$/);if(t){let[,e,n,r]=t,i=this.globalVariables[e]===void 0?0:this.globalVariables[e],a=Number(r)||r.replace(/['"]/g,``);n===`=`?this.globalVariables[e]=a:n===`+=`?this.globalVariables[e]=Number(i)+Number(a):n===`-=`?this.globalVariables[e]=Number(i)-Number(a):n===`*=`?this.globalVariables[e]=Number(i)*Number(a):n===`/=`&&(this.globalVariables[e]=Number(i)/(Number(a)||1))}}catch(e){console.warn(`Error executing prototype mutation:`,e)}}},y=class{constructor(e){this.doc=e}auditPage(e){let t=(this.doc.pages||[]).find(t=>t.id===e)||this.doc.pages?.[0];if(!t)return{totalFrames:0,reachableFrames:0,coveragePct:0,brokenLinks:[],deadEnds:[],circularDelays:[]};let n=[],r=new Map,i=new Map,a=[],o=new Map;for(let e of t.rootIds||[]){let a=t.nodes[e];a&&a.type===`frame`&&(n.push(e),r.set(e,new Set),i.set(e,new Set))}let s=n.find(e=>t.nodes[e]?.isFlowStart)||n[0]||null;for(let e in t.nodes){let s=t.nodes[e];if(!s||!s.interactions||s.interactions.length===0)continue;let c=null,l=s;for(;l;){if(n.includes(l.id)){c=l.id;break}l=l.parentId?t.nodes[l.parentId]:null}for(let e of s.interactions)e.targetId&&(t.nodes[e.targetId]?c&&n.includes(e.targetId)&&(r.get(c)?.add(e.targetId),i.get(e.targetId)?.add(c),(e.trigger===`delay`||e.trigger===`after-delay`)&&o.set(c,e.targetId)):a.push({sourceNodeId:s.id,sourceNodeName:s.name,ownerFrameId:c,targetId:e.targetId,reason:`Target frame or layer no longer exists`}))}let c=new Set;if(s){let e=[s];for(c.add(s);e.length>0;){let t=e.shift(),n=r.get(t)||new Set;for(let t of n)c.has(t)||(c.add(t),e.push(t))}}let l=[];for(let e of c)(r.get(e)?.size||0)===0&&l.push({frameId:e,frameName:t.nodes[e]?.name||e});let u=[];for(let[e,t]of o.entries()){let n=t,r=o.get(t);for(;n&&r&&o.get(r);){if(n===r){u.push({frameId:e,loopFrame:n});break}n=o.get(n),r=o.get(o.get(r))}}let d=n.length,f=c.size;return{totalFrames:d,reachableFrames:f,coveragePct:d>0?Math.round(f/d*100):100,startFrameId:s,brokenLinks:a,deadEnds:l,circularDelays:u,unreachableFrameIds:n.filter(e=>!c.has(e))}}repairBrokenLinks(e,t){let n=(this.doc.pages||[]).find(t=>t.id===e)||this.doc.pages?.[0];if(!n)return 0;let r=0;for(let e in n.nodes){let i=n.nodes[e];if(!i||!i.interactions||i.interactions.length===0)continue;let a=i.interactions.filter(e=>!e.targetId||!!n.nodes[e.targetId]);a.length!==i.interactions.length&&(r+=i.interactions.length-a.length,t.updateNode(i.id,{interactions:a},`Repair broken prototype links`))}return r}},b=class{constructor(e,t,n,r){this.x1=Math.max(0,Math.min(1,e)),this.y1=t,this.x2=Math.max(0,Math.min(1,n)),this.y2=r}calcX(e){let t=3*this.x1,n=3*(this.x2-this.x1)-t;return(((1-t-n)*e+n)*e+t)*e}calcY(e){let t=3*this.y1,n=3*(this.y2-this.y1)-t;return(((1-t-n)*e+n)*e+t)*e}getSlopeX(e){let t=3*this.x1,n=3*(this.x2-this.x1)-t;return(3*(1-t-n)*e+2*n)*e+t}solveCurveX(e,t=1e-6){if(e<=0)return 0;if(e>=1)return 1;let n=e;for(let r=0;r<8;r++){let r=this.calcX(n)-e;if(Math.abs(r)<t)return n;let i=this.getSlopeX(n);if(Math.abs(i)<1e-6)break;n-=r/i}let r=0,i=1;for(n=e;r<i;){let a=this.calcX(n);if(Math.abs(a-e)<t)return n;e>a?r=n:i=n,n=(i+r)*.5}return n}evaluate(e,t=1e-6){if(e<=0)return 0;if(e>=1)return 1;let n=this.solveCurveX(e,t);return this.calcY(n)}solve(e,t=1e-6){return this.evaluate(e,t)}};new b(0,0,1,1),new b(.25,.1,.25,1),new b(.42,0,1,1),new b(0,0,.58,1),new b(.42,0,.58,1),new b(.16,1,.3,1),new b(.05,.7,.1,1),new b(.2,0,0,1),Array.from({length:125},(e,t)=>`assets/sketch-data/Faces/${String(t+1).padStart(3,`0`)}.jpg`),[`02`,`03`,`04`,`05_altcolor`,`06`,`07`,`08`,`09`,`10`,`11`,`12`,`13`,`14`,`15`,`16`,`17`,`18`,`19`].map(e=>`assets/sketch-data/Tiles/1024x1024_tile_${e}.png`);var x=new Uint8Array(512),S=new Uint8Array(256);(function(){let e=1;for(let t=0;t<255;t++)x[t]=e,x[t+255]=e,S[e]=t,e=e<<1^(e&128?285:0);S[0]=0})();function C(e,t){return e===0||t===0?0:x[S[e]+S[t]]}function w(e){let t=[1];for(let n=0;n<e;n++){let e=[1,x[n]],r=Array(t.length+1).fill(0);for(let n=0;n<t.length;n++)for(let i=0;i<e.length;i++)r[n+i]^=C(t[n],e[i]);t=r}return t}function T(e,t){let n=w(t),r=Array(e.length+t).fill(0);for(let t=0;t<e.length;t++)r[t]=e[t];for(let t=0;t<e.length;t++){let e=r[t];if(e!==0)for(let i=0;i<n.length;i++)r[t+i]^=C(n[i],e)}return r.slice(e.length)}var E={1:{L:{total:26,data:19,ec:7,blocks:1},M:{total:26,data:16,ec:10,blocks:1}},2:{L:{total:44,data:34,ec:10,blocks:1},M:{total:44,data:28,ec:16,blocks:1}},3:{L:{total:70,data:55,ec:15,blocks:1},M:{total:70,data:44,ec:26,blocks:1}},4:{L:{total:100,data:80,ec:20,blocks:1},M:{total:100,data:64,ec:18,blocks:2}},5:{L:{total:134,data:108,ec:26,blocks:1},M:{total:134,data:86,ec:24,blocks:2}},6:{L:{total:172,data:136,ec:18,blocks:2},M:{total:172,data:108,ec:16,blocks:4}},7:{L:{total:196,data:156,ec:20,blocks:2},M:{total:196,data:124,ec:18,blocks:4}},8:{L:{total:242,data:194,ec:24,blocks:2},M:{total:242,data:154,ec:22,blocks:4}},9:{L:{total:292,data:232,ec:30,blocks:2},M:{total:292,data:182,ec:22,blocks:5}},10:{L:{total:346,data:274,ec:18,blocks:4},M:{total:346,data:216,ec:26,blocks:5}}},D={1:[],2:[6,18],3:[6,22],4:[6,26],5:[6,30],6:[6,34],7:[6,22,38],8:[6,24,42],9:[6,26,46],10:[6,28,50]},O={L:[30660,29427,32170,30877,26159,25368,27713,26998],M:[21522,20773,24188,23371,17913,16590,20375,19104]},k=class{constructor(e,t={}){this.text=String(e),this.ecLevel=(t.ecLevel||`L`).toUpperCase(),this.version=this.selectVersion(this.text,this.ecLevel),this.size=this.version*4+17,this.modules=[],this.isFunction=[],this.generate()}selectVersion(e,t){let n=new TextEncoder().encode(e).length;for(let e=1;e<=10;e++){let r=E[e][t],i=e<=9?8:16,a=r.data*8;if(4+i+n*8<=a)return e}return 10}generate(){for(let e=0;e<this.size;e++)this.modules[e]=new Uint8Array(this.size),this.isFunction[e]=new Uint8Array(this.size);this.addFinder(0,0),this.addFinder(this.size-7,0),this.addFinder(0,this.size-7),this.addSeparators(),this.addTimingPatterns(),this.addAlignmentPatterns(),this.reserveFormatInfo();let e=this.encodeDataCodewords(),t=this.selectBestMask(e);this.placeDataAndMask(e,t),this.placeFormatInfo(t)}addFinder(e,t){for(let n=0;n<7;n++)for(let r=0;r<7;r++){let i=n===0||n===6||r===0||r===6||n>=2&&n<=4&&r>=2&&r<=4;this.modules[e+n][t+r]=+!!i,this.isFunction[e+n][t+r]=1}}addSeparators(){for(let e=0;e<8;e++)e<7&&(this.isFunction[7][e]=1,this.isFunction[e][7]=1),this.isFunction[7][7]=1,e<7&&(this.isFunction[7][this.size-8+e]=1,this.isFunction[e][this.size-8]=1),this.isFunction[7][this.size-8]=1,e<7&&(this.isFunction[this.size-8+e][7]=1,this.isFunction[this.size-8][e]=1),this.isFunction[this.size-8][7]=1}addTimingPatterns(){for(let e=8;e<this.size-8;e++)this.isFunction[6][e]||(this.modules[6][e]=+(e%2==0),this.isFunction[6][e]=1),this.isFunction[e][6]||(this.modules[e][6]=+(e%2==0),this.isFunction[e][6]=1)}addAlignmentPatterns(){let e=D[this.version]||[];for(let t of e)for(let n of e)if(!this.isFunction[t][n])for(let e=-2;e<=2;e++)for(let r=-2;r<=2;r++){let i=Math.abs(e)===2||Math.abs(r)===2||e===0&&r===0;this.modules[t+e][n+r]=+!!i,this.isFunction[t+e][n+r]=1}}reserveFormatInfo(){for(let e=0;e<9;e++)this.isFunction[8][e]=1,this.isFunction[e][8]=1;for(let e=0;e<8;e++)this.isFunction[8][this.size-8+e]=1,this.isFunction[this.size-8+e][8]=1;this.modules[this.size-8][8]=1,this.isFunction[this.size-8][8]=1}encodeDataCodewords(){let e=E[this.version][this.ecLevel],t=e.data,n=new TextEncoder().encode(this.text),r=[],i=(e,t)=>{for(let n=t-1;n>=0;n--)r.push(e>>n&1)};i(4,4);let a=this.version<=9?8:16;i(n.length,a);for(let e of n)i(e,8);let o=t*8,s=Math.min(4,o-r.length);for(let e=0;e<s;e++)r.push(0);for(;r.length%8!=0;)r.push(0);let c=[];for(let e=0;e<r.length;e+=8){let t=0;for(let n=0;n<8;n++)t=t<<1|r[e+n];c.push(t)}let l=[236,17],u=0;for(;c.length<t;)c.push(l[u%2]),u++;let d=e.blocks,f=e.ec,p=Math.floor(t/d),m=Math.floor(f/d),h=[],g=[];for(let e=0;e<d;e++){let n=e*p,r=e===d-1?t:(e+1)*p,i=c.slice(n,r);h.push(i),g.push(T(i,m))}let _=[],v=Math.max(...h.map(e=>e.length));for(let e=0;e<v;e++)for(let t=0;t<d;t++)e<h[t].length&&_.push(h[t][e]);for(let e=0;e<m;e++)for(let t=0;t<d;t++)e<g[t].length&&_.push(g[t][e]);return _}isMaskCondition(e,t,n){switch(e){case 0:return(t+n)%2==0;case 1:return t%2==0;case 2:return n%3==0;case 3:return(t+n)%3==0;case 4:return(Math.floor(t/2)+Math.floor(n/3))%2==0;case 5:return t*n%2+t*n%3==0;case 6:return(t*n%2+t*n%3)%2==0;case 7:return((t+n)%2+t*n%3)%2==0;default:return!1}}placeDataAndMask(e,t){let n=0,r=e.length*8,i=!0;for(let a=this.size-1;a>0;a-=2){a===6&&(a=5);let o=[];if(i)for(let e=this.size-1;e>=0;e--)o.push(e);else for(let e=0;e<this.size;e++)o.push(e);for(let i of o)for(let o of[a,a-1])if(!this.isFunction[i][o]){let a=0;n<r&&(a=e[Math.floor(n/8)]>>7-n%8&1,n++),this.isMaskCondition(t,i,o)&&(a^=1),this.modules[i][o]=a}i=!i}}selectBestMask(e){return 2}placeFormatInfo(e){let t=O[this.ecLevel][e];for(let e=0;e<15;e++){let n=t>>14-e&1;e<6?this.modules[8][e]=n:e===6?this.modules[8][7]=n:e===7?this.modules[8][8]=n:e===8?this.modules[7][8]=n:this.modules[14-e][8]=n,e<8?this.modules[this.size-1-e][8]=n:this.modules[8][this.size-15+e]=n}}toSVG(e={}){let t=e.size||256,n=e.padding===void 0?4:e.padding,r=e.darkColor||`#000000`,i=e.lightColor||`#ffffff`,a=(t/(this.size+n*2)).toFixed(3),o=[];for(let e=0;e<this.size;e++)for(let t=0;t<this.size;t++)if(this.modules[e][t]===1){let i=((t+n)*a).toFixed(2),s=((e+n)*a).toFixed(2);o.push(`<rect x="${i}" y="${s}" width="${a}" height="${a}" fill="${r}" />`)}return`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${t} ${t}" width="${t}" height="${t}" shape-rendering="crispEdges">
  <rect width="100%" height="100%" fill="${i}" />
  ${o.join(`
  `)}
</svg>`}};function A(e,t={}){return new k(e,t).toSVG(t)}var j=class{constructor(){this.builtins={min:(...e)=>Math.min(...e.flat()),max:(...e)=>Math.max(...e.flat()),round:e=>Math.round(e),floor:e=>Math.floor(e),ceil:e=>Math.ceil(e),clamp:(e,t,n)=>Math.min(Math.max(e,t),n),abs:e=>Math.abs(e),pow:(e,t)=>e**+t,sqrt:e=>Math.sqrt(e),concat:(...e)=>e.join(``),contains:(e,t)=>String(e||``).includes(t),startsWith:(e,t)=>String(e||``).startsWith(t),endsWith:(e,t)=>String(e||``).endsWith(t),length:e=>String(e||``).length,upper:e=>String(e||``).toUpperCase(),lower:e=>String(e||``).toLowerCase(),trim:e=>String(e||``).trim(),format:(e,...t)=>{let n=String(e||``);return t.forEach((e,t)=>{n=n.replace(RegExp(`\\{${t}\\}`,`g`),String(e))}),n},len:e=>Array.isArray(e)?e.length:e?Object.keys(e).length:0,sum:e=>Array.isArray(e)?e.reduce((e,t)=>e+(Number(t)||0),0):0,avg:e=>!Array.isArray(e)||e.length===0?0:e.reduce((e,t)=>e+(Number(t)||0),0)/e.length,sort:e=>Array.isArray(e)?[...e].sort():[],slice:(e,t,n)=>Array.isArray(e)?e.slice(t,n):[],any:(e,t)=>Array.isArray(e)?typeof t==`function`?e.some(t):e.some(Boolean):!1,all:(e,t)=>Array.isArray(e)?typeof t==`function`?e.every(t):e.every(Boolean):!1,now:()=>Date.now(),addDays:(e,t)=>Number(e||Date.now())+t*864e5,diff:(e,t,n=`days`)=>{let r=Math.abs(Number(e)-Number(t));return n===`hours`?r/36e5:n===`minutes`?r/6e4:n===`seconds`?r/1e3:r/864e5},if:(e,t,n)=>e?t:n,coalesce:(...e)=>e.find(e=>e!=null)??null,isEmpty:e=>!!(e==null||e===``||Array.isArray(e)&&e.length===0||typeof e==`object`&&Object.keys(e).length===0),isEmail:e=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(e||``).trim()),isPhone:e=>/^[+]?[(]?[0-9]{1,4}[)]?[-\s./0-9]{6,15}$/.test(String(e||``).trim()),matches:(e,t)=>{try{return new RegExp(t).test(String(e||``))}catch{return!1}},required:e=>!this.builtins.isEmpty(e),minLen:(e,t)=>String(e||``).length>=t,maxLen:(e,t)=>String(e||``).length<=t,mix:(e,t,n=.5)=>e||t,lighten:(e,t=.1)=>e,darken:(e,t=.1)=>e,contrast:(e,t)=>4.5}}evaluate(e,t={}){if(!e||typeof e!=`string`||e.trim()===``)return!0;let n=e.trim().replace(/\band\b/g,`&&`).replace(/\bor\b/g,`||`).replace(/\bnot\s+/g,`!`).replace(/\bif\s*\(/g,`__if(`);try{let e={...this.builtins,...t};e.if&&(e.__if=e.if,delete e.if);let r=new Set(`break.case.catch.class.const.continue.debugger.default.delete.do.else.export.extends.finally.for.function.if.import.in.instanceof.new.return.super.switch.this.throw.try.typeof.var.void.while.with.yield.let.static.enum.await`.split(`.`)),i=Object.entries(e).filter(([e])=>/^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(e)&&!r.has(e)),a=i.map(([e])=>e),o=i.map(([,e])=>e);return Function(...a,`
        'use strict';
        return (${n});
      `)(...o)}catch{return null}}evaluatePredicate(e,t={}){return!!this.evaluate(e,t)}};new j;var M=class{constructor(){this.collections=new Map,this.endpoints=new Map}registerCollection(e,t=[]){if(typeof e==`object`&&e){let t=e.id||e.name,n={id:t,name:e.name||t,schema:e.schema||{},records:Array.isArray(e.records)?[...e.records]:[]};return this.collections.set(t,n),n}let n={id:e,name:e,records:Array.isArray(t)?[...t]:[]};return this.collections.set(e,n),n}setCollection(e,t=[]){return this.registerCollection(e,t)}getCollection(e){return this.collections.get(e)||{id:e,name:e,records:[]}}findRecords(e,t){return(this.getCollection(e).records||[]).filter(t)}addRecord(e,t){let n=this.getCollection(e),r={id:t.id||`rec_${Date.now()}_${Math.random().toString(36).substr(2,5)}`,...t};return n.records.push(r),r}insertRecord(e,t){return this.addRecord(e,t)}updateRecord(e,t,n){let r=this.getCollection(e),i=(r.records||[]).findIndex(e=>e.id===t);return i===-1?null:(r.records[i]={...r.records[i],...n},r.records[i])}deleteRecord(e,t){let n=this.getCollection(e),r=(n.records||[]).length;return n.records=(n.records||[]).filter(e=>e.id!==t),n.records.length<r}registerEndpoint(e,t,n={}){if(typeof e==`object`&&e){let{method:t=`GET`,path:n,responseStatus:r=200,responseData:i={}}=e,a=`${t.toUpperCase()}:${n}`;this.endpoints.set(a,{method:t.toUpperCase(),path:n,status:r,data:i,latency:e.latency||0,failureRate:e.failureRate||0,responseTemplate:i});return}let r=`${e.toUpperCase()}:${t}`;this.endpoints.set(r,{method:e.toUpperCase(),path:t,status:n.status||200,data:n.responseTemplate||n.data||{success:!0},latency:n.latency||0,failureRate:n.failureRate||0,responseTemplate:n.responseTemplate||{success:!0}})}async fetchMock(e,t,n={},r={}){let i=`${e.toUpperCase()}:${t}`,a=this.endpoints.get(i)||{status:200,data:n,latency:0,failureRate:0,responseTemplate:n};if(a.latency>0&&await new Promise(e=>setTimeout(e,Math.min(a.latency,300))),a.failureRate>0&&Math.random()<a.failureRate)return{ok:!1,status:500,error:`Simulated Network Failure`};let o=typeof a.responseTemplate==`function`?a.responseTemplate(n,r):a.data===void 0?a.responseTemplate:a.data;return{ok:!0,status:a.status||200,data:o}}},N=String.raw`
(function () {
  const doc = window.__DFORGE_DOC__;
  const toolbar = document.getElementById('playerToolbar');
  const screen = document.getElementById('deviceScreen');
  const bezel = document.getElementById('activeDeviceBezel');
  const dynamicIsland = document.getElementById('dynamicIsland');
  const flowLabel = document.getElementById('activeFlowLabel');
  const flowSelect = document.getElementById('protoFlowSelect');
  const scaleSelect = document.getElementById('protoScaleSelect');
  const deviceSelect = document.getElementById('protoDeviceSelect');
  const btnPrev = document.getElementById('btnPrevFrame');
  const btnNext = document.getElementById('btnNextFrame');
  const btnToggleHints = document.getElementById('btnToggleHints');
  const btnToggleDebugger = document.getElementById('btnToggleDebugger');
  const debuggerDrawer = document.getElementById('debuggerDrawer');
  const dbgVarsPane = document.getElementById('dbgVarsPane');
  const dbgEventsPane = document.getElementById('dbgEventsPane');
  const dbgVarCount = document.getElementById('dbgVarCount');
  const dbgEventCount = document.getElementById('dbgEventCount');
  const btnClearLog = document.getElementById('btnClearLog');
  const btnCloseDebugger = document.getElementById('btnCloseDebugger');

  const pages = doc.pages || [];
  let page = pages[0] || { nodes: {} };
  let currentFrameId = doc.initialFrameId;
  const history = [];
  const overlays = [];
  const eventLog = [];
  let showHotspotHints = true;
  let activeScaleMode = 'fit'; // 'fit' | '100' | 'width'
  let currentDevice = 'responsive';

  // Reactive Variables Store
  const variables = {};
  for (const v of doc.variables || []) {
    const k = v.id || v.name;
    const val = v.value !== undefined ? v.value : (v.initialValue !== undefined ? v.initialValue : (v.type === 'number' ? 0 : v.type === 'boolean' ? false : ''));
    variables[k] = val;
    if (v.name && v.id && v.name !== v.id) {
      variables[v.name] = val;
    }
  }

  // Active delay timers for cleanup
  let activeDelayTimers = [];
  function clearDelayTimers() {
    activeDelayTimers.forEach(t => clearTimeout(t));
    activeDelayTimers = [];
  }

  function getNode(id) {
    for (const candidate of pages) {
      if (candidate.nodes && candidate.nodes[id]) return candidate.nodes[id];
    }
    return null;
  }

  function getFrames() {
    return (page.rootIds || [])
      .map(id => page.nodes[id])
      .filter(n => n && n.type === 'frame');
  }

  function escapeText(value) {
    return String(value == null ? '' : value);
  }

  function cssColor(value, fallback) {
    return typeof value === 'string' && value.trim() ? value : fallback;
  }

  function fillStyle(node) {
    const fill = (node.style && node.style.fills || []).find(item => item.visible !== false);
    if (!fill) return 'transparent';
    if (fill.type === 'linear-gradient' || fill.type === 'gradient') {
      const stops = fill.stops || [{ offset: 0, color: fill.color || '#334155' }, { offset: 1, color: '#8b5cf6' }];
      return 'linear-gradient(135deg, ' + stops.map(stop => stop.color + ' ' + (stop.offset * 100) + '%').join(', ') + ')';
    }
    return cssColor(fill.color, '#334155');
  }

  // Evaluates mathematical/logical expressions in prototype scope
  function evaluateExpr(expr, scope = {}) {
    if (!expr || typeof expr !== 'string') return expr;
    const s = { ...variables, ...scope };
    s.min = Math.min;
    s.max = Math.max;
    s.round = Math.round;
    s.floor = Math.floor;
    s.ceil = Math.ceil;
    s.abs = Math.abs;
    s.clamp = (val, min, max) => Math.min(Math.max(val, min), max);
    s.concat = (...args) => args.join('');
    s.contains = (str, sub) => String(str || '').includes(sub);
    s.upper = (str) => String(str || '').toUpperCase();
    s.lower = (str) => String(str || '').toLowerCase();
    s.length = (str) => String(str || '').length;
    s.trim = (str) => String(str || '').trim();
    s.len = (list) => Array.isArray(list) ? list.length : (list ? Object.keys(list).length : 0);
    s.sum = (list) => Array.isArray(list) ? list.reduce((a, b) => a + (Number(b) || 0), 0) : 0;
    s.avg = (list) => Array.isArray(list) && list.length ? s.sum(list) / list.length : 0;
    s.if = (cond, thenVal, elseVal) => cond ? thenVal : elseVal;
    s.isEmail = (str) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(str || '').trim());
    s.isPhone = (str) => /^[+]?[(]?[0-9]{1,4}[)]?[-\s./0-9]{6,15}$/.test(String(str || '').trim());
    s.required = (val) => val !== null && val !== undefined && val !== '';

    let norm = expr.trim()
      .replace(/\band\b/g, '&&')
      .replace(/\bor\b/g, '||')
      .replace(/\bnot\s+/g, '!')
      .replace(/\bif\s*\(/g, '__if(');

    if (s['if']) {
      s['__if'] = s['if'];
      delete s['if'];
    }

    try {
      const keys = Object.keys(s).filter(k => /^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(k));
      const vals = keys.map(k => s[k]);
      const fn = new Function(...keys, '"use strict"; return (' + norm + ');');
      return fn(...vals);
    } catch (e) {
      return null;
    }
  }

  // Interpolates variable expressions like {counter} in text content
  function interpolateText(content) {
    if (typeof content !== 'string') return content;
    return content.replace(/\{([a-zA-Z0-9_$.]+)\}/g, (match, varName) => {
      const v = variables[varName];
      return v !== undefined ? String(v) : match;
    });
  }

  function updateDynamicBindings() {
    screen.querySelectorAll('.prototype-text').forEach(el => {
      const raw = el.dataset.rawContent;
      if (raw) el.textContent = interpolateText(raw);
    });
    updateDebuggerView();
  }

  function flashHotspotHints() {
    if (!showHotspotHints) return;
    const hotspots = screen.querySelectorAll('[data-interactive="true"]');
    hotspots.forEach(el => {
      el.classList.remove('hotspot-pulse');
      void el.offsetWidth;
      el.classList.add('hotspot-pulse');
      setTimeout(() => el.classList.remove('hotspot-pulse'), 500);
    });
  }

  function logEvent(trigger, sourceName, desc) {
    const time = new Date().toTimeString().split(' ')[0];
    eventLog.unshift({ time, trigger, sourceName: sourceName || 'Canvas', desc });
    if (eventLog.length > 50) eventLog.pop();
    updateDebuggerView();
  }

  function updateDebuggerView() {
    if (!debuggerDrawer || debuggerDrawer.style.display === 'none') return;
    if (dbgVarCount) dbgVarCount.textContent = Object.keys(variables).length;
    if (dbgEventCount) dbgEventCount.textContent = eventLog.length;

    if (dbgVarsPane) {
      const vKeys = Object.keys(variables);
      if (vKeys.length === 0) {
        dbgVarsPane.innerHTML = '<div style="color: #64748b; font-size: 11px; padding: 8px;">No variables defined in document.</div>';
      } else {
        dbgVarsPane.innerHTML = '<table class="dbg-table"><thead><tr><th>Name</th><th>Value</th><th>Live Override</th></tr></thead><tbody>' +
          vKeys.map(k => {
            const val = variables[k];
            const type = typeof val;
            return '<tr><td><code>' + k + '</code></td><td><span class="type-pill">' + type + '</span> ' + escapeText(val) + '</td><td><input class="dbg-input" data-var="' + k + '" value="' + escapeText(val) + '"></td></tr>';
          }).join('') + '</tbody></table>';

        dbgVarsPane.querySelectorAll('.dbg-input').forEach(inp => {
          inp.addEventListener('change', (e) => {
            const k = inp.dataset.var;
            let v = e.target.value;
            if (typeof variables[k] === 'number') v = Number(v) || 0;
            else if (typeof variables[k] === 'boolean') v = v === 'true';
            variables[k] = v;
            logEvent('debug_edit', 'Debugger', k + ' -> ' + v);
            updateDynamicBindings();
          });
        });
      }
    }

    if (dbgEventsPane) {
      if (eventLog.length === 0) {
        dbgEventsPane.innerHTML = '<div style="color: #64748b; font-size: 11px; padding: 8px;">No events recorded yet. Click hotspots to interact.</div>';
      } else {
        dbgEventsPane.innerHTML = eventLog.map(e =>
          '<div class="dbg-event-row"><span class="dbg-time">' + e.time + '</span><span class="dbg-badge">' + e.trigger + '</span><span class="dbg-source">' + escapeText(e.sourceName) + '</span><span class="dbg-desc">' + escapeText(e.desc) + '</span></div>'
        ).join('');
      }
    }
  }

  function mountNode(node, parentElement, parentNodeId) {
    if (!node || node.visible === false || !node.transform) return;
    const isInputType = (node.type === 'text' || node.type === 'frame') && (
      (node.name && /input|field|textbox|search|email|password/i.test(node.name)) ||
      (node.interactions || []).some(i => i.trigger === 'change' || i.trigger === 'input' || i.action === 'set_variable')
    );

    const element = document.createElement(isInputType && node.type === 'text' ? 'input' : 'div');
    const transform = node.transform;
    const style = node.style || {};
    const bounds = page.prototypeBounds && page.prototypeBounds[node.id];
    const parentBounds = page.prototypeBounds && page.prototypeBounds[parentNodeId];
    const stroke = (style.strokes || []).find(item => item.visible !== false);
    element.className = 'prototype-node prototype-' + node.type;
    element.dataset.nodeId = node.id;
    element.dataset.nodeName = node.name || node.type;
    element.style.left = (bounds && parentBounds ? bounds.x - parentBounds.x : transform.x || 0) + 'px';
    element.style.top = (bounds && parentBounds ? bounds.y - parentBounds.y : transform.y || 0) + 'px';
    element.style.width = Math.max(0, transform.width || 0) + 'px';
    element.style.height = Math.max(0, transform.height || 0) + 'px';
    element.style.opacity = String(node.opacity == null ? 1 : node.opacity);
    element.style.transform = 'rotate(' + (transform.rotation || 0) + 'deg) scale(' + (transform.scaleX == null ? 1 : transform.scaleX) + ', ' + (transform.scaleY == null ? 1 : transform.scaleY) + ')';
    element.style.background = fillStyle(node);
    element.style.borderRadius = typeof style.cornerRadius === 'number' ? style.cornerRadius + 'px' : '0';
    element.style.mixBlendMode = style.blendMode && style.blendMode !== 'normal' ? style.blendMode : '';
    if (stroke) {
      element.style.border = (stroke.width || 1) + 'px ' + (stroke.style === 'dashed' ? 'dashed' : 'solid') + ' ' + cssColor(stroke.color, '#3b82f6');
    }
    if (style.shadows && style.shadows.length) {
      element.style.boxShadow = style.shadows.map(shadow => (shadow.x || 0) + 'px ' + (shadow.y || 0) + 'px ' + (shadow.blur || 0) + 'px ' + cssColor(shadow.color, 'rgba(0,0,0,.35)')).join(', ');
    }
    if (node.type === 'ellipse') element.style.borderRadius = '50%';
    if (node.type === 'star') element.style.clipPath = 'polygon(50% 0%, 62% 35%, 100% 38%, 72% 61%, 82% 100%, 50% 77%, 18% 100%, 28% 61%, 0 38%, 38% 35%)';
    if (node.type === 'polygon') element.style.clipPath = 'polygon(50% 0%, 100% 100%, 0 100%)';
    if (node.type === 'section' || node.type === 'slice') {
      element.style.background = 'transparent';
      element.style.border = '1px dashed #6366f1';
    }
    if (node.type === 'text' && node.text) {
      const text = node.text;
      const rawText = escapeText(text.content);
      element.dataset.rawContent = rawText;
      if (element.tagName === 'INPUT') {
        element.value = interpolateText(rawText);
        element.style.outline = 'none';
        element.style.border = 'none';
        element.style.background = 'transparent';
      } else {
        element.textContent = interpolateText(rawText);
      }
      element.style.color = cssColor(text.color, '#f8fafc');
      element.style.fontFamily = text.fontFamily || 'Inter, sans-serif';
      element.style.fontSize = (text.fontSize || 16) + 'px';
      element.style.fontWeight = text.fontWeight || '400';
      element.style.textAlign = text.textAlign || 'left';
      element.style.whiteSpace = 'pre';
      element.style.lineHeight = String(text.lineHeight || 1.3);
      element.style.letterSpacing = (text.letterSpacing || 0) + 'px';
    }
    if (node.type === 'frame') {
      element.style.overflow = node.clipContent === false ? 'visible' : 'hidden';
    }

    parentElement.appendChild(element);

    for (const childId of node.childIds || []) {
      mountNode(page.nodes[childId], element, node.id);
    }

    const interactions = node.interactions || [];
    if (interactions.length > 0) {
      element.dataset.interactive = 'true';
      element.style.cursor = 'pointer';

      // Setup gesture drag tracking if on-drag trigger present
      let dragStartX = 0, dragStartY = 0, isDragging = false;
      const dragInteraction = interactions.find(i => i.trigger === 'drag');
      if (dragInteraction) {
        element.addEventListener('pointerdown', (e) => {
          dragStartX = e.clientX;
          dragStartY = e.clientY;
          isDragging = true;
        });
        window.addEventListener('pointermove', (e) => {
          if (!isDragging) return;
          const dist = Math.hypot(e.clientX - dragStartX, e.clientY - dragStartY);
          if (dist > 8) {
            isDragging = false;
            runInteraction(dragInteraction, node);
          }
        });
        window.addEventListener('pointerup', () => { isDragging = false; });
      }

      for (const interaction of interactions) {
        const trigger = interaction.trigger || 'click';

        if (trigger === 'click' || trigger === 'tap') {
          element.addEventListener('click', (e) => {
            e.stopPropagation();
            runInteraction(interaction, node);
          });
        } else if (trigger === 'hover' || trigger === 'enter') {
          element.addEventListener('pointerenter', (e) => {
            e.stopPropagation();
            runInteraction(interaction, node);
          });
        } else if (trigger === 'leave') {
          element.addEventListener('pointerleave', (e) => {
            e.stopPropagation();
            runInteraction(interaction, node);
          });
        } else if (trigger === 'press' || trigger === 'down') {
          element.addEventListener('pointerdown', (e) => {
            e.stopPropagation();
            runInteraction(interaction, node);
          });
        } else if (trigger === 'up') {
          element.addEventListener('pointerup', (e) => {
            e.stopPropagation();
            runInteraction(interaction, node);
          });
        }
      }
    }

    // Interactive input handling
    if (isInputType) {
      element.addEventListener('input', (e) => {
        const val = e.target.value;
        const boundVar = (interactions.find(i => i.action === 'set_variable') || {}).variableId || node.name;
        if (boundVar && variables[boundVar] !== undefined) {
          variables[boundVar] = val;
          updateDynamicBindings();
        }
      });
    }
  }

  function renderFrame(frameId, animation, easing, duration) {
    const frame = getNode(frameId);
    if (!frame || !page.nodes[frameId]) return;
    clearDelayTimers();
    currentFrameId = frameId;
    overlays.length = 0;
    screen.innerHTML = '';

    const frameElement = document.createElement('div');
    const animClass = animation && animation !== 'instant' ? ' transition-' + animation : '';
    frameElement.className = 'prototype-frame' + animClass;
    frameElement.style.width = Math.max(1, frame.transform.width || 1) + 'px';
    frameElement.style.height = Math.max(1, frame.transform.height || 1) + 'px';
    frameElement.style.background = fillStyle(frame);
    frameElement.style.borderRadius = typeof frame.style?.cornerRadius === 'number' ? frame.style.cornerRadius + 'px' : '0';
    frameElement.style.position = 'relative';
    frameElement.style.overflow = frame.clipContent === false ? 'visible' : 'hidden';
    frameElement.style.color = '#f8fafc';
    frameElement.style.transformOrigin = 'top center';
    frameElement.dataset.frameId = frame.id;

    // Apply animation duration & easing if provided
    if (duration) frameElement.style.animationDuration = duration + 'ms';
    if (easing) frameElement.style.animationTimingFunction = easing;

    for (const childId of frame.childIds || []) mountNode(page.nodes[childId], frameElement, frame.id);
    screen.appendChild(frameElement);

    if (flowLabel) flowLabel.textContent = 'Flow: ' + (frame.flowName || frame.name || 'Prototype');
    if (flowSelect) {
      for (let i = 0; i < flowSelect.options.length; i++) {
        if (flowSelect.options[i].value === frame.id) flowSelect.selectedIndex = i;
      }
    }

    // Schedule After-Delay triggers on frame layers
    const scanDelayTriggers = (nodeId) => {
      const n = getNode(nodeId);
      if (!n) return;
      for (const inter of n.interactions || []) {
        if (inter.trigger === 'delay' || inter.trigger === 'after_delay' || inter.trigger === 'after-delay') {
          const delayMs = Number(inter.delay || inter.delayMs || inter.timeout || 500);
          const tId = setTimeout(() => {
            runInteraction(inter, n);
          }, delayMs);
          activeDelayTimers.push(tId);
        }
      }
      for (const cid of n.childIds || []) scanDelayTriggers(cid);
    };
    scanDelayTriggers(frameId);

    // Frame empty area click triggers hotspot hint pulse
    frameElement.addEventListener('click', () => {
      flashHotspotHints();
    });

    fitFrame(frameElement);
    logEvent('navigate', frame.name, 'Screen mounted (' + (animation || 'instant') + ')');
    updateDynamicBindings();
  }

  function fitFrame(frame) {
    if (!frame) return;
    let scale = 1;
    if (activeScaleMode === 'fit') {
      scale = Math.min(screen.clientWidth / frame.offsetWidth, screen.clientHeight / frame.offsetHeight, 1);
    } else if (activeScaleMode === 'width') {
      scale = Math.min(screen.clientWidth / frame.offsetWidth, 1);
    } else {
      scale = 1;
    }
    frame.style.transform = 'scale(' + Math.max(0.1, scale) + ')';
    frame.style.marginLeft = 'auto';
    frame.style.marginRight = 'auto';
    frame.style.marginBottom = Math.max(0, frame.offsetHeight * (scale - 1)) + 'px';
  }

  function renderOverlay(frameId, interaction = {}) {
    const frame = getNode(frameId);
    if (!frame) return;
    const pos = interaction.overlayPosition || interaction.position || 'center';
    const backdrop = document.createElement('div');
    backdrop.className = 'prototype-overlay-backdrop';
    if (pos === 'top-center' || pos === 'top-left' || pos === 'top-right') backdrop.style.alignItems = 'flex-start';
    if (pos === 'bottom-center' || pos === 'bottom-left' || pos === 'bottom-right') backdrop.style.alignItems = 'flex-end';
    if (pos === 'top-left' || pos === 'bottom-left') backdrop.style.justifyContent = 'flex-start';
    if (pos === 'top-right' || pos === 'bottom-right') backdrop.style.justifyContent = 'flex-end';

    backdrop.addEventListener('click', (e) => {
      if (interaction.closeOnClickOutside !== false) {
        closeOverlay();
      }
    });

    const overlayFrame = document.createElement('div');
    overlayFrame.className = 'prototype-overlay-frame';
    overlayFrame.style.width = Math.min(frame.transform.width || 360, screen.clientWidth * 0.95) + 'px';
    overlayFrame.style.height = Math.min(frame.transform.height || 240, screen.clientHeight * 0.95) + 'px';
    overlayFrame.style.background = fillStyle(frame);
    overlayFrame.style.overflow = frame.clipContent === false ? 'visible' : 'hidden';
    overlayFrame.addEventListener('click', event => event.stopPropagation());
    for (const childId of frame.childIds || []) mountNode(page.nodes[childId], overlayFrame, frame.id);
    backdrop.appendChild(overlayFrame);
    screen.appendChild(backdrop);
    overlays.push(backdrop);
    logEvent('overlay', frame.name, 'Overlay opened at ' + pos);
  }

  function closeOverlay() {
    const overlay = overlays.pop();
    if (overlay) overlay.remove();
    logEvent('close_overlay', 'Overlay', 'Overlay dismissed');
  }

  function runInteraction(interaction, sourceNode = null) {
    // Condition Guard Evaluation
    if (interaction.condition || interaction.guard) {
      const cond = interaction.condition || interaction.guard;
      const passed = evaluateExpr(cond);
      if (!passed) {
        logEvent('guard_blocked', sourceNode?.name, 'Condition failed: ' + cond);
        if (interaction.elseAction) runInteraction(interaction.elseAction, sourceNode);
        return;
      }
    }

    const action = interaction.action || 'navigate';

    if (action === 'navigate' || action === 'navigate_to') {
      const target = interaction.targetId || interaction.destinationFrameId;
      if (!getNode(target)) return;
      history.push(currentFrameId);
      renderFrame(target, interaction.animation || interaction.transition, interaction.easing, interaction.duration || interaction.durationMs);
    } else if (action === 'overlay' || action === 'open_overlay') {
      const target = interaction.targetId || interaction.overlayFrameId || interaction.destinationFrameId;
      if (!getNode(target)) return;
      renderOverlay(target, interaction);
    } else if (action === 'swap_overlay') {
      closeOverlay();
      const target = interaction.targetId || interaction.overlayFrameId;
      if (getNode(target)) renderOverlay(target, interaction);
    } else if (action === 'close_overlay' || action === 'close') {
      closeOverlay();
    } else if (action === 'back') {
      const previous = history.pop();
      if (previous) renderFrame(previous, interaction.animation || 'dissolve');
      logEvent('back', sourceNode?.name, 'Navigated back');
    } else if (action === 'scroll_to') {
      const target = screen.querySelector('[data-node-id="' + interaction.targetId + '"]');
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        logEvent('scroll_to', sourceNode?.name, 'Scrolled to ' + interaction.targetId);
      }
    } else if (action === 'url' && interaction.url) {
      try {
        const url = new URL(interaction.url, window.location.href);
        if (url.protocol === 'https:' || url.protocol === 'http:') {
          window.open(url.href, interaction.newTab !== false ? '_blank' : '_self', 'noopener');
          logEvent('url', sourceNode?.name, 'Opened URL ' + url.href);
        }
      } catch (error) {
        console.error('Invalid URL:', error);
      }
    } else if (action === 'set_variable') {
      const varId = interaction.variableId || interaction.varId || interaction.variable || interaction.name;
      let val = interaction.value;
      const expr = interaction.expr || interaction.expression;
      const op = interaction.operator || interaction.op || '=';

      if (expr) {
        val = evaluateExpr(expr);
      } else if (op && op !== '=') {
        const cur = variables[varId] || 0;
        if (op === '+=' || op === 'add') val = Number(cur) + Number(val || 1);
        else if (op === '-=' || op === 'sub') val = Number(cur) - Number(val || 1);
        else if (op === '*=' || op === 'mul') val = Number(cur) * Number(val || 1);
        else if (op === '/=' || op === 'div') val = Number(val) !== 0 ? Number(cur) / Number(val) : 0;
        else if (op === 'toggle') val = !Boolean(cur);
      }
      variables[varId] = val;
      logEvent('set_variable', sourceNode?.name, varId + ' = ' + val);
      updateDynamicBindings();
    } else if (action === 'conditional') {
      const cond = interaction.condition || interaction.expr;
      const passed = evaluateExpr(cond);
      logEvent('conditional', sourceNode?.name, cond + ' => ' + passed);
      if (passed && interaction.thenAction) {
        runInteraction(interaction.thenAction, sourceNode);
      } else if (!passed && interaction.elseAction) {
        runInteraction(interaction.elseAction, sourceNode);
      }
    } else if (action === 'change_to' || action === 'change_variant') {
      logEvent('change_to', sourceNode?.name, 'Variant swapped to ' + (interaction.targetVariantId || interaction.variant));
    }
  }

  function restart() {
    clearDelayTimers();
    history.length = 0;
    overlays.length = 0;
    renderFrame(doc.initialFrameId, 'instant');
    logEvent('restart', 'Player', 'Prototype restarted from origin');
  }

  function applyDevicePreset(preset) {
    currentDevice = preset;
    if (!bezel) return;
    if (preset === 'iphone16') {
      bezel.style.width = '393px';
      bezel.style.height = '852px';
      bezel.style.border = '12px solid #1c1c1e';
      bezel.style.borderRadius = '54px';
      bezel.style.boxShadow = '0 25px 60px rgba(0,0,0,0.85), 0 0 0 1px rgba(255,255,255,0.08)';
      if (dynamicIsland) dynamicIsland.style.display = 'block';
    } else if (preset === 'pixel9') {
      bezel.style.width = '412px';
      bezel.style.height = '923px';
      bezel.style.border = '10px solid #202124';
      bezel.style.borderRadius = '36px';
      bezel.style.boxShadow = '0 25px 60px rgba(0,0,0,0.85)';
      if (dynamicIsland) dynamicIsland.style.display = 'none';
    } else if (preset === 'ipad') {
      bezel.style.width = '768px';
      bezel.style.height = '1024px';
      bezel.style.border = '14px solid #1e293b';
      bezel.style.borderRadius = '28px';
      bezel.style.boxShadow = '0 25px 60px rgba(0,0,0,0.85)';
      if (dynamicIsland) dynamicIsland.style.display = 'none';
    } else if (preset === 'macbook') {
      bezel.style.width = '1000px';
      bezel.style.height = '625px';
      bezel.style.border = '14px solid #0f172a';
      bezel.style.borderRadius = '14px';
      bezel.style.boxShadow = '0 25px 60px rgba(0,0,0,0.85)';
      if (dynamicIsland) dynamicIsland.style.display = 'none';
    } else {
      bezel.style.width = '100%';
      bezel.style.height = '100%';
      bezel.style.border = '0';
      bezel.style.borderRadius = '0';
      bezel.style.boxShadow = 'none';
      if (dynamicIsland) dynamicIsland.style.display = 'none';
    }
    const cur = screen.querySelector('.prototype-frame');
    if (cur) fitFrame(cur);
  }

  // Populate Flow starting points dropdown
  if (flowSelect) {
    const frames = getFrames();
    flowSelect.innerHTML = frames.map(f => {
      const name = f.flowName || f.name;
      const isStart = f.isFlowStart ? ' [Start] ' : '';
      return '<option value="' + f.id + '" ' + (f.id === currentFrameId ? 'selected' : '') + '>' + isStart + escapeText(name) + '</option>';
    }).join('');

    flowSelect.addEventListener('change', (e) => {
      clearDelayTimers();
      history.length = 0;
      overlays.length = 0;
      renderFrame(e.target.value, 'dissolve');
    });
  }

  if (deviceSelect) {
    deviceSelect.addEventListener('change', (e) => applyDevicePreset(e.target.value));
  }

  if (scaleSelect) {
    scaleSelect.addEventListener('change', (e) => {
      activeScaleMode = e.target.value;
      const cur = screen.querySelector('.prototype-frame');
      if (cur) fitFrame(cur);
    });
  }

  if (btnPrev) {
    btnPrev.addEventListener('click', () => {
      const prev = history.pop();
      if (prev) renderFrame(prev, 'slide-left');
    });
  }

  if (btnNext) {
    btnNext.addEventListener('click', () => {
      const frames = getFrames();
      const idx = frames.findIndex(f => f.id === currentFrameId);
      if (idx !== -1 && idx < frames.length - 1) {
        history.push(currentFrameId);
        renderFrame(frames[idx + 1].id, 'slide-left');
      }
    });
  }

  if (btnToggleHints) {
    btnToggleHints.addEventListener('click', () => {
      showHotspotHints = !showHotspotHints;
      btnToggleHints.style.color = showHotspotHints ? '#38bdf8' : '#94a3b8';
      btnToggleHints.style.borderColor = showHotspotHints ? '#38bdf8' : '#334155';
      flashHotspotHints();
    });
  }

  if (btnToggleDebugger) {
    btnToggleDebugger.addEventListener('click', () => {
      if (!debuggerDrawer) return;
      const isClosed = debuggerDrawer.style.display === 'none';
      debuggerDrawer.style.display = isClosed ? 'flex' : 'none';
      btnToggleDebugger.style.color = isClosed ? '#38bdf8' : '#f8fafc';
      updateDebuggerView();
    });
  }

  if (btnCloseDebugger) {
    btnCloseDebugger.addEventListener('click', () => {
      if (debuggerDrawer) debuggerDrawer.style.display = 'none';
      if (btnToggleDebugger) btnToggleDebugger.style.color = '#f8fafc';
    });
  }

  if (btnClearLog) {
    btnClearLog.addEventListener('click', () => {
      eventLog.length = 0;
      updateDebuggerView();
    });
  }

  // Debugger Tab Switcher
  document.querySelectorAll('.dbg-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.dbg-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const t = tab.dataset.tab;
      if (dbgVarsPane) dbgVarsPane.style.display = t === 'vars' ? 'block' : 'none';
      if (dbgEventsPane) dbgEventsPane.style.display = t === 'events' ? 'block' : 'none';
    });
  });

  // Global Keyboard Shortcuts for presentation player
  window.addEventListener('keydown', (e) => {
    // Avoid capturing inputs if active
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

    if (e.key === 'r' || e.key === 'R') {
      restart();
    } else if (e.key === 'h' || e.key === 'H') {
      btnToggleHints?.click();
    } else if (e.key === 'd' || e.key === 'D') {
      btnToggleDebugger?.click();
    } else if (e.key === 'Escape') {
      if (overlays.length > 0) closeOverlay();
      else if (debuggerDrawer?.style.display === 'flex') btnCloseDebugger?.click();
    } else if (e.key === 'ArrowLeft') {
      btnPrev?.click();
    } else if (e.key === 'ArrowRight') {
      btnNext?.click();
    }

    // Match interactive key triggers on active frame
    const curFrame = getNode(currentFrameId);
    if (curFrame) {
      const matchKeyInteractions = (nodeId) => {
        const n = getNode(nodeId);
        if (!n) return;
        for (const inter of n.interactions || []) {
          if (inter.trigger === 'key' && (!inter.key || inter.key.toLowerCase() === e.key.toLowerCase())) {
            runInteraction(inter, n);
          }
        }
        for (const cid of n.childIds || []) matchKeyInteractions(cid);
      };
      matchKeyInteractions(currentFrameId);
    }
  });

  document.getElementById('btnRestart')?.addEventListener('click', restart);
  window.addEventListener('resize', () => {
    const frame = screen.querySelector('.prototype-frame');
    if (frame) fitFrame(frame);
  });

  if (toolbar) toolbar.hidden = false;
  if (currentFrameId) renderFrame(currentFrameId, 'instant');
})();
`,P=class{constructor(e={}){this.id=e.id||e.name,this.name=e.name||e.id,this.type=e.type||`string`,this.value=e.value===void 0?null:e.value,this.isComputed=!!e.isComputed,this.expression=e.expression||null,this.scope=e.scope||`global`}valueOf(){return this.value}[Symbol.toPrimitive](e){return e===`number`?Number(this.value):e===`string`?String(this.value):this.value}toString(){return String(this.value)}},F=class{constructor(e){this.engine=e,this.variablesMap=new Map}createVariable(e){let t=new P(e);return this.variablesMap.set(t.id,t),t.name&&this.variablesMap.set(t.name,t),this.engine.variables.set(t.id,t.value),t.name&&this.engine.variables.set(t.name,t.value),t.isComputed&&t.expression&&(this.engine.computedVariables.set(t.id,t.expression),t.name&&this.engine.computedVariables.set(t.name,t.expression)),t}setVariable(e,t){let n=this.variablesMap.get(e);return n&&(n.value=t),this.engine.variables.set(e,t),this.recomputeGraph(),t}getVariable(e){if(this.variablesMap.has(e))return this.variablesMap.get(e);if(this.engine.variables.has(e)){let t=new P({id:e,value:this.engine.variables.get(e)});return this.variablesMap.set(e,t),t}return null}recomputeGraph(){this.engine.recomputeVariables();for(let[e,t]of this.variablesMap.entries())t.isComputed&&t.expression&&(t.value=this.engine.variables.get(e))}getVariablesSnapshot(){let e={};for(let[t,n]of this.engine.variables.entries())e[t]=n;for(let[t,n]of this.variablesMap.entries())e[t]=n.value,n.name&&(e[n.name]=n.value);return e}},I=class{constructor(e){this.doc=e,this.currentDevice=`desktop`,this.currentFrameId=null,this.navigationHistory=[],this.activeOverlays=[],this.overlays=[],this.instanceVariants=new Map,this.variables=new Map,this.variableScopes=new Map,this.computedVariables=new Map,this.variablesStore=new F(this),this.evaluator=new j,this.dataLayer=new M,this.stateMachines=new Map,this.diagnostics=new y(e),this.hfsm=new v,this.gestureTracker=new _,this.virtualTimeMs=0,this.isPaused=!1,this.timeScale=1,this.eventLog=[],this.snapshots=[],this.delayedTimers=[],this.flows=this.getFlows(),this.environment={orientation:`portrait`,theme:`dark`,network:`online`,keyboardVisible:!1,reducedMotion:!1},this.initVariables(),this.recordSnapshot(`initial`)}initVariables(){let e=this.variablesStore?new Map(this.variablesStore.variablesMap):null;if(this.variables.clear(),this.variableScopes.clear(),this.computedVariables.clear(),this.doc?.variables){let e=this.doc.themeMode||`dark`;for(let t of this.doc.variables){let n=t.value===void 0?t.values?.[e]===void 0?t.values?.default:t.values[e]:t.value;n!==void 0&&this.setVariable(t.name||t.id,n,t.scope||`global`)}}if(e){for(let[t,n]of e.entries())this.variables.set(t,n.value),n.isComputed&&n.expression&&this.computedVariables.set(t,n.expression);this.variablesStore.variablesMap=e,this.recomputeVariables()}this.prototypeVariables=this.variables}createVariable(e){return this.variablesStore.createVariable(e)}setVariable(e,t,n=`global`){this.variables.set(e,t),this.variableScopes.set(e,n),this.hfsm.setVariable(e,t);let r=this.variablesStore.variablesMap.get(e);return r&&(r.value=t),this.variablesStore.recomputeGraph(),this.handleReactiveEvent(`variable_changed`,{variable:e,value:t}),t}getVariable(e,t=null){return this.variablesStore.getVariable(e)||(this.variables.has(e)?this.variables.get(e):t)}stepVirtualClock(e=0){return this.virtualTimeMs+=e,this.virtualTimeMs}recordSnapshot(e=`snapshot`){let t={id:`snap_${Date.now()}_${Math.random().toString(36).substr(2,5)}`,label:e,timestamp:this.virtualTimeMs,currentFrameId:this.currentFrameId,variables:this.getVariablesSnapshot(),overlays:[...this.overlays]};return this.snapshots.push(t),t}defineComputedVariable(e,t){this.computedVariables.set(e,t),this.recomputeVariables()}recomputeVariables(){for(let e=0;e<3;e++){let e=this.getVariablesSnapshot(),t=!1;for(let[n,r]of this.computedVariables.entries())try{let i=this.evaluator.evaluate(r,e);this.variables.get(n)!==i&&(this.variables.set(n,i),this.hfsm.setVariable(n,i),e[n]=i,t=!0)}catch(e){console.warn(`Error computing variable ${n}:`,e)}if(!t)break}}getVariablesSnapshot(){let e={};for(let[t,n]of this.variables.entries())e[t]=n;return e}evaluateExpression(e,t={}){let n={...this.getVariablesSnapshot(),...t};return this.evaluator.evaluate(e,n)}evaluatePredicate(e,t={}){let n={...this.getVariablesSnapshot(),...t};return this.evaluator.evaluatePredicate(e,n)}setDevice(e){this.currentDevice=e}getDeviceDimensions(){switch(this.currentDevice){case`mobile`:return{width:375,height:812,label:`iPhone 15 Pro (375 × 812)`};case`tablet`:return{width:768,height:1024,label:`iPad Mini (768 × 1024)`};case`desktop`:return{width:1440,height:900,label:`Desktop MacBook (1440 × 900)`};default:return{width:`100%`,height:`100%`,label:`Fluid Responsive`}}}getFlows(){let e=[];for(let t of this.doc.pages||[])for(let n of t.rootIds||[]){let r=t.nodes[n];r?.isFlowStart&&r.type===`frame`&&e.push({id:`flow_${r.id}`,name:r.flowName||r.name||`Main Flow`,startingFrameId:r.id,description:r.flowDescription||`User journey starting point`})}return e}setFlowStartingPoints(e){return this.flows=Array.isArray(e)?[...e]:[],this.flows}startFlow(e=null){this.cancelDelayedActions(),this.activeOverlays=[],this.overlays=[],this.instanceVariants.clear(),this.initVariables();let t=e;if(t&&this.flows&&this.flows.length>0){let e=this.flows.find(e=>e.id===t||e.name===t);e&&(t=e.startingFrameId)}if(!t){for(let e of this.doc.pages||[]){for(let n of e.rootIds||[]){let r=e.nodes[n];if(r?.isFlowStart&&r.type===`frame`){t=n;break}}if(t)break}if(!t){let e=this.doc.pages?.[0];t=e?.rootIds?.find(t=>e.nodes[t]?.type===`frame`)||null}!t&&this.doc?.rootFrameIds?.[0]&&(t=this.doc.rootFrameIds[0])}return this.currentFrameId=t,this.navigationHistory=[],t&&(this.handleLifecycleEvent(`on_load`,t),this.scheduleDelayActions(t)),this.originFrameId||=t,this.logEvent(`start_flow`,null,[{action:`start_flow`,targetId:t}]),t}restart(){let e=this.originFrameId||this.navigationHistory[0]||null;return this.startFlow(e)}getState(){return{currentFrameId:this.currentFrameId,activeFlowId:this.activeFlowId||null,history:[...this.navigationHistory],overlays:[...this.overlays],variables:this.getVariablesSnapshot(),virtualTimeMs:this.virtualTimeMs,device:this.currentDevice}}handleInteraction(e,t=`click`,n={}){return this.handleEvent(e,t,n)}resetState(){return this.restart()}getCurrentFrame(){if(!this.currentFrameId)return null;for(let e of this.doc.pages||[])if(e.nodes?.[this.currentFrameId])return e.nodes[this.currentFrameId];return null}getHistory(){return[...this.navigationHistory]}goBack(){return this.executeAction({action:`back`})}getActiveOverlay(){if(this.activeOverlays.length===0)return null;let e=this.activeOverlays[this.activeOverlays.length-1];return this.findNode(e.frameId)}handleEvent(e,t=`click`,n={}){let r=this.findNode(e);if(!r||!r.interactions||r.interactions.length===0)return{success:!1,reason:`No interactions on node`};let i=r.interactions.filter(e=>{let r=(e.trigger||`click`).toLowerCase(),i=(t||`click`).toLowerCase();return(i===`click`||i===`tap`)&&(r===`click`||r===`tap`)||i===`double_tap`&&(r===`double_tap`||r===`doubleclick`)||i===`long_press`&&r===`long_press`||i===`hover`&&(r===`hover`||r===`enter`||r===`hover_enter`||r===`mouse_enter`)||i===`leave`&&(r===`leave`||r===`hover_leave`||r===`mouse_leave`)||i===`press`&&(r===`press`||r===`press_down`||r===`mouse_down`)||i===`drag`&&(r===`drag`||r===`drag_start`||r===`drag_move`)||i.startsWith(`swipe_`)&&r===i?!0:i===`key`&&(r===`key`||r===`keyboard`)?!e.key||String(e.key).toLowerCase()===String(n.key||``).toLowerCase():i===`delay`&&(r===`delay`||r===`after_delay`||r===`after-delay`)||i===`load`&&(r===`load`||r===`on_load`)||r===i});if(i.length===0)return{success:!1,reason:`No matching trigger found`};let a=[];for(let t of i){if(t.condition||t.guard||t.predicate){let r=t.guard||t.predicate||t.condition,i=!1;if(typeof r==`string`)i=this.evaluatePredicate(r,n);else if(typeof r==`object`){let{varId:e,op:t,val:n}=r,a=this.getVariable(e);t===`==`?i=a==n:t===`!=`?i=a!=n:t===`>`?i=a>n:t===`<`?i=a<n:t===`>=`?i=a>=n:t===`<=`&&(i=a<=n)}if(!i){t.elseAction&&a.push(this.executeAction(t.elseAction,e,n));continue}}let r=this.executeAction(t,e,n);a.push(r)}return this.logEvent(t,e,a),a.length>0?a[0]:{success:!0}}handleLifecycleEvent(e,t){if(!this.findNode(t))return;let n=t=>{let r=this.findNode(t);if(r){if(r.interactions)for(let t of r.interactions)t.trigger===e&&this.executeAction(t,r.id);if(r.childIds)for(let e of r.childIds)n(e)}};n(t)}handleReactiveEvent(e,t={}){for(let[n,r]of this.stateMachines.entries())r.send(e,{...this.getVariablesSnapshot(),...t},this.evaluator)}executeAction(e,t=null,n={}){let r=e.action||`navigate`,i=e.destinationFrameId||e.targetId;if((r===`navigate`||r===`navigate_to`)&&i)return this.findNode(i)?(this.cancelDelayedActions(),this.currentFrameId&&this.navigationHistory.push(this.currentFrameId),this.currentFrameId=i,this.scheduleDelayActions(i),this.handleLifecycleEvent(`on_load`,i),{success:!0,action:`navigate`,targetId:i,animation:e.transition||e.animation||`smart-animate`,duration:e.durationMs||e.duration||300,easing:e.easing||`ease-in-out`}):{success:!1,error:`Target frame ${i} not found`};if(r===`back`){if(this.navigationHistory.length>0){let e=this.navigationHistory.pop();return this.cancelDelayedActions(),this.currentFrameId=e,this.scheduleDelayActions(e),{success:!0,action:`back`,targetId:e}}return{success:!1,reason:`Already at flow start`}}if(r===`change_to`||r===`change_variant`||r===`change-variant`||r===`set_variant`){let n=e.targetVariantId||e.variantId||e.variant,r=e.targetNodeId||t;if(r&&n)return this.instanceVariants.set(r,n),{success:!0,action:`change_to`,nodeId:r,variantId:n,animation:e.animation||`instant`}}if(r===`overlay`||r===`open_overlay`){let t=e.overlayFrameId||e.targetId;if(!this.findNode(t))return{success:!1,error:`Overlay target ${t} not found`};let n=e.overlaySettings||e.overlayOptions||{position:`centered`,closeOnClickOutside:!0,closeOnEscape:!0,dimBackground:!0},r={overlayFrameId:t,targetId:t,frameId:t,options:n,settings:n};return this.overlays.push(r),this.activeOverlays.push(r),{success:!0,action:`open_overlay`,targetId:t,overlay:r}}if(r===`close_overlay`||r===`close`){let e=this.overlays.pop()||this.activeOverlays.pop();return{success:!0,action:`close_overlay`,targetId:e?.overlayFrameId||e?.frameId}}if(r===`swap_overlay`){this.overlays.pop(),this.activeOverlays.length>0&&this.activeOverlays.pop();let t=e.overlayFrameId||e.targetId,n=e.overlaySettings||e.overlayOptions||{position:`center`,dimBackground:!0},r={overlayFrameId:t,targetId:t,frameId:t,options:n,settings:n};return this.overlays.push(r),this.activeOverlays.push(r),{success:!0,action:`swap_overlay`,targetId:t}}if(r===`set_variable`){let t=e.variableId||e.varId||e.variable||e.name,r=e.value===void 0?e.variableUpdate?.value:e.value,i=e.expr||e.expression||e.variableUpdate?.expr,a=e.operator||e.op||`=`;if(i)r=this.evaluateExpression(i,{...this.getVariablesSnapshot(),...n});else if(a&&a!==`=`){let e=this.getVariable(t,0),n=e&&typeof e==`object`&&e.value!==void 0?e.value:e;a===`+=`||a===`add`?r=Number(n||0)+Number(r||1):a===`-=`||a===`sub`?r=Number(n||0)-Number(r||1):a===`*=`||a===`mul`?r=Number(n||0)*Number(r||1):a===`/=`||a===`div`?r=Number(r)===0?0:Number(n||0)/Number(r):a===`toggle`&&(r=!n)}return this.setVariable(t,r),{success:!0,action:`set_variable`,varId:t,variableId:t,value:r,op:a}}if(r===`set_variable_mode`){let t=e.collection||`default`,n=e.mode||`light`;return this.setVariable(`mode_${t}`,n),{success:!0,action:`set_variable_mode`,collection:t,mode:n}}if(r===`conditional`){let r=e.condition||e.expr||e.predicate,i=this.evaluatePredicate(r,{...this.getVariablesSnapshot(),...n});return i&&e.thenAction?this.executeAction(e.thenAction,t,n):!i&&e.elseAction?this.executeAction(e.elseAction,t,n):{success:!0,action:`conditional`,passed:i}}if(r===`toggle`||r===`toggle_variable`){let t=e.variableId||e.varId||e.variable,n=!!this.getVariable(t,!1);return this.setVariable(t,!n),{success:!0,action:`toggle`,varId:t,value:!n}}if(r===`increment`||r===`increment_variable`){let t=e.variableId||e.varId||e.variable,n=Number(e.step||1),r=Number(this.getVariable(t,0));return this.setVariable(t,r+n),{success:!0,action:`increment`,varId:t,value:r+n}}if(r===`send_event`){let n=e.targetNodeId||t,r=this.stateMachines.get(n);if(r)return{success:!0,action:`send_event`,...r.send(e.event,this.getVariablesSnapshot(),this.evaluator)}}if(r===`fetch_mock`||r===`fetch`){let r=e.method||`GET`,i=e.path||`/api/data`,a=e.payload||n;return this.dataLayer.fetchMock(r,i,a,this.getVariablesSnapshot()).then(n=>{n.ok&&e.onSuccess?this.executeAction(e.onSuccess,t,{response:n.data}):!n.ok&&e.onError&&this.executeAction(e.onError,t,{error:n.error})}),{success:!0,action:`fetch_mock`,path:i}}if(r===`assert`){let t=e.condition||e.expression||e.predicate;return!!this.evaluatePredicate(t,n)}return r===`scroll_to`&&e.targetId?{success:!0,action:`scroll_to`,targetId:e.targetId}:r===`url`&&e.url?{success:!0,action:`url`,url:e.url}:{success:!0,action:r}}cancelDelayedActions(){for(let e of this.delayedTimers)clearTimeout(e);this.delayedTimers=[]}scheduleDelayActions(e){if(this.cancelDelayedActions(),!this.findNode(e))return;let t=e=>{let n=this.findNode(e);if(n){if(n.interactions&&n.interactions.length>0)for(let e of n.interactions){let t=e.trigger;if(t===`delay`||t===`after_delay`||t===`after-delay`){let t=e.delayMs||e.delay||1e3,r=setTimeout(()=>{this.executeAction(e,n.id)},t);r&&typeof r.unref==`function`&&r.unref(),this.delayedTimers.push(r)}}if(n.childIds)for(let e of n.childIds)t(e)}};t(e)}logEvent(e,t,n){let r={id:`evt_${Date.now()}_${Math.random().toString(36).substr(2,5)}`,timestamp:Date.now(),virtualTime:this.virtualTimeMs,trigger:e,sourceNodeId:t,currentFrameId:this.currentFrameId,actions:n,stateSnapshot:this.getVariablesSnapshot()};return this.eventLog.push(r),this.recordSnapshot(`event_${e}`),r}recordSnapshot(e=`manual`){this.snapshots.push({timestamp:Date.now(),label:e,currentFrameId:this.currentFrameId,navigationHistory:[...this.navigationHistory],variables:this.getVariablesSnapshot(),activeOverlays:[...this.activeOverlays]}),this.snapshots.length>50&&this.snapshots.shift()}timeTravelTo(e){if(e>=0&&e<this.snapshots.length){let t=this.snapshots[e];this.currentFrameId=t.currentFrameId,this.navigationHistory=[...t.navigationHistory],this.activeOverlays=[...t.activeOverlays],this.variables.clear();for(let[e,n]of Object.entries(t.variables))this.setVariable(e,n);return!0}return!1}createSpring(e=1,t=100,n=10){return new g({mass:e,stiffness:t,damping:n})}createCubicBezier(e,t,n,r){return new b(e,t,n,r)}matchLayers(e,t){let n=this.findNode(e),r=this.findNode(t);if(!n||!r)return[];let i=[],a=(e,t=[])=>{if(t.push(e),e.childIds)for(let n of e.childIds){let e=this.findNode(n);e&&a(e,t)}return t},o=a(n),s=a(r);for(let e of o){let t=s.find(t=>t.id===e.id);if(t){i.push({source:e,target:t,matchType:`id`});continue}let n=s.find(t=>t.name===e.name&&t.type===e.type);n&&i.push({source:e,target:n,matchType:`name`})}return i}findNode(e){if(this.doc?.nodes?.[e])return this.doc.nodes[e];for(let t of this.doc.pages||[])if(t.nodes?.[e])return t.nodes[e];return null}escapeHtml(e){return String(e||``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}generatePrototypeHtml(){let e=this.doc.pages?.[0];if(!e)return`<div>No active design document found.</div>`;let t=(this.doc.pages||[]).map(e=>{let t=new Map,n=Object.fromEntries(Object.keys(e.nodes||{}).map(n=>[n,f(e,n,t)]));return{...e,prototypeBounds:n}}),n=(e.rootIds||[]).map(t=>e.nodes[t]).filter(e=>e&&e.type===`frame`),r=this.currentFrameId||n.find(e=>e.isFlowStart)?.id||n[0]?.id||null,i=JSON.stringify({name:this.doc.name,pages:t,components:this.doc.components||[],variables:this.doc.variables||[],tokens:this.doc.tokens||[],initialFrameId:r}).replace(/</g,`\\u003c`);return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${this.escapeHtml(this.doc.name)} — Prototype Presentation</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; }
    body, html {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
      background: #090d16;
      font-family: 'Inter', -apple-system, sans-serif;
      color: #f8fafc;
      overflow: hidden;
      user-select: none;
    }
    #playerContainer {
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
      position: relative;
    }
    #playerToolbar {
      height: 44px;
      background: #0f172a;
      border-bottom: 1px solid #1e293b;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 16px;
      z-index: 100;
    }
    .tool-group {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .player-select {
      background: #1e293b;
      color: #f8fafc;
      border: 1px solid #334155;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 500;
      padding: 4px 8px;
      outline: none;
      cursor: pointer;
    }
    .player-select:hover {
      border-color: #0ea5e9;
    }
    .btn-player {
      background: #1e293b;
      color: #f8fafc;
      border: 1px solid #334155;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 600;
      padding: 4px 10px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      transition: all 0.15s ease;
    }
    .btn-player:hover {
      background: #334155;
      border-color: #0d99ff;
    }
    @media (max-width: 480px) {
      #playerToolbar {
        padding: 0 8px;
        gap: 8px;
      }
      #playerToolbar .tool-group {
        min-width: 0;
        gap: 6px;
      }
      #playerToolbar .tool-group:first-child {
        flex: 1;
      }
      #playerToolbar .tool-group:first-child > span:first-child {
        font-size: 11px !important;
        white-space: nowrap;
      }
      #activeFlowLabel {
        display: none;
      }
      #btnRestart {
        font-size: 10px;
        padding: 4px 6px;
        white-space: nowrap;
      }
    }
    #viewportWrapper {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      background: radial-gradient(circle at center, #131b2e 0%, #090d16 100%);
      overflow: auto;
    }
    .device-bezel {
      border: 12px solid #1e293b;
      border-radius: 40px;
      box-shadow: 0 25px 60px rgba(0,0,0,0.8), 0 0 0 1px rgba(255,255,255,0.05);
      position: relative;
      overflow: hidden;
      background: #000;
      transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .dynamic-island {
      width: 96px;
      height: 26px;
      background: #000;
      border-radius: 20px;
      position: absolute;
      top: 10px;
      left: calc(50% - 48px);
      z-index: 50;
      box-shadow: 0 0 0 1px rgba(255,255,255,0.08);
      pointer-events: none;
    }
    .device-screen {
      width: 100%;
      height: 100%;
      overflow-y: auto;
      overflow-x: hidden;
      position: relative;
      display: flex;
      align-items: flex-start;
      justify-content: center;
      background: #090d16;
    }
    .prototype-frame {
      flex: 0 0 auto;
      transform-origin: top center;
      box-shadow: 0 12px 40px rgba(0,0,0,.32);
    }
    .prototype-node {
      position: absolute;
      box-sizing: border-box;
      transform-origin: center;
      user-select: none;
    }
    .prototype-node[data-node-id] {
      cursor: default;
    }
    .prototype-node[data-interactive="true"] {
      cursor: pointer;
    }
    .hotspot-pulse {
      outline: 2px solid #38bdf8 !important;
      box-shadow: 0 0 16px rgba(56, 189, 248, 0.8) !important;
      animation: hotspotAnim 0.4s ease-out;
    }
    @keyframes hotspotAnim {
      0% { outline-color: rgba(56,189,248,0.2); box-shadow: 0 0 0 rgba(56,189,248,0); }
      50% { outline-color: rgba(56,189,248,1); box-shadow: 0 0 20px rgba(56,189,248,0.9); }
      100% { outline-color: rgba(56,189,248,0.2); box-shadow: 0 0 0 rgba(56,189,248,0); }
    }
    .prototype-overlay-backdrop {
      position: absolute;
      inset: 0;
      z-index: 20;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 18px;
      background: rgba(0,0,0,.55);
      animation: overlayFadeIn 0.2s ease-out;
    }
    @keyframes overlayFadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    .prototype-overlay-frame {
      position: relative;
      max-width: 100%;
      max-height: 100%;
      border-radius: 12px;
      box-shadow: 0 18px 48px rgba(0,0,0,.45);
      animation: overlayPop 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes overlayPop {
      from { transform: scale(0.95); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }
    .transition-dissolve {
      animation: prototypeFade .22s ease-out;
    }
    .transition-smart-animate {
      animation: prototypeSmart .28s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .transition-slide-left {
      animation: prototypeSlideL .24s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .transition-slide-right {
      animation: prototypeSlideR .24s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .transition-slide-up {
      animation: prototypeSlideU .24s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .transition-slide-down {
      animation: prototypeSlideD .24s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .transition-push {
      animation: prototypePush .24s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes prototypeFade {
      from { opacity: .35; }
      to { opacity: 1; }
    }
    @keyframes prototypeSmart {
      from { opacity: .6; transform: scale(0.98); }
      to { opacity: 1; transform: scale(1); }
    }
    @keyframes prototypeSlideL {
      from { opacity: .55; transform: translateX(24px); }
      to { opacity: 1; transform: translateX(0); }
    }
    @keyframes prototypeSlideR {
      from { opacity: .55; transform: translateX(-24px); }
      to { opacity: 1; transform: translateX(0); }
    }
    @keyframes prototypeSlideU {
      from { opacity: .55; transform: translateY(24px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes prototypeSlideD {
      from { opacity: .55; transform: translateY(-24px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes prototypePush {
      from { transform: translateX(30px); }
      to { transform: translateX(0); }
    }

    /* Live Debugger Drawer */
    .debugger-drawer {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      height: 220px;
      background: #090d16;
      border-top: 1px solid #1e293b;
      z-index: 150;
      display: flex;
      flex-direction: column;
      box-shadow: 0 -8px 24px rgba(0,0,0,0.5);
    }
    .debugger-header {
      height: 36px;
      background: #0f172a;
      border-bottom: 1px solid #1e293b;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 12px;
    }
    .debugger-tabs {
      display: flex;
      gap: 6px;
    }
    .dbg-tab {
      background: transparent;
      border: none;
      color: #94a3b8;
      font-size: 11px;
      font-weight: 600;
      padding: 6px 10px;
      border-radius: 4px;
      cursor: pointer;
    }
    .dbg-tab.active {
      background: #1e293b;
      color: #38bdf8;
    }
    .debugger-body {
      flex: 1;
      overflow-y: auto;
      padding: 8px 12px;
    }
    .dbg-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 11px;
    }
    .dbg-table th, .dbg-table td {
      padding: 5px 8px;
      text-align: left;
      border-bottom: 1px solid rgba(255,255,255,0.05);
    }
    .dbg-table th {
      color: #64748b;
      font-weight: 600;
    }
    .dbg-input {
      background: #1e293b;
      border: 1px solid #334155;
      color: #f8fafc;
      border-radius: 4px;
      padding: 2px 6px;
      font-size: 11px;
      width: 120px;
    }
    .type-pill {
      font-size: 9px;
      background: rgba(56,189,248,0.15);
      color: #38bdf8;
      padding: 1px 4px;
      border-radius: 3px;
      margin-right: 4px;
    }
    .dbg-event-row {
      font-size: 11px;
      font-family: 'JetBrains Mono', monospace;
      padding: 4px 6px;
      border-bottom: 1px solid rgba(255,255,255,0.04);
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .dbg-time { color: #64748b; }
    .dbg-badge {
      background: rgba(56,189,248,0.15);
      color: #38bdf8;
      border-radius: 3px;
      padding: 1px 4px;
      font-size: 10px;
    }
    .dbg-source { color: #f8fafc; font-weight: 600; }
    .dbg-desc { color: #94a3b8; }
  </style>
</head>
<body>
  <div id="playerContainer">
    <div id="playerToolbar">
      <div class="tool-group">
        <span style="font-weight: 700; color: #818cf8; font-size: 13px; display: inline-flex; align-items: center; gap: 6px;">
          <img src="assets/logo-64.png" alt="DesignForge" style="width: 18px; height: 18px; border-radius: 4px; object-fit: contain;" onerror="this.style.display='none'">
          DesignForge Prototype
        </span>
        <span id="activeFlowLabel" style="font-size: 11px; color: #94a3b8;">Flow: Main</span>
        <select id="protoFlowSelect" class="player-select" title="Switch active prototype flow"></select>
      </div>
      <div class="tool-group">
        <select id="protoDeviceSelect" class="player-select" title="Switch device frame">
          <option value="responsive">Responsive Canvas</option>
          <option value="iphone16">iPhone 16 Pro (393 × 852)</option>
          <option value="pixel9">Google Pixel 9 (412 × 923)</option>
          <option value="ipad">iPad Pro (768 × 1024)</option>
          <option value="macbook">MacBook Pro (1000 × 625)</option>
        </select>
        <select id="protoScaleSelect" class="player-select" title="Display zoom scale">
          <option value="fit">Fit to Screen</option>
          <option value="100">100% Actual Size</option>
          <option value="width">Fit Width</option>
        </select>
        <button class="btn-player" id="btnPrevFrame" title="Previous Screen (Left Arrow)"><span data-icon="ChevronLeft"></span></button>
        <button class="btn-player" id="btnNextFrame" title="Next Screen (Right Arrow)"><span data-icon="ChevronRight"></span></button>
        <button class="btn-player" id="btnToggleHints" title="Toggle Hotspot Hints (H)"><span data-icon="Lightbulb"></span> Hints</button>
        <button class="btn-player" id="btnToggleDebugger" title="Toggle Variables & Event Debugger (D)"><span data-icon="Bug"></span> Debugger</button>
        <button class="btn-player" id="btnRestart">↺ Restart (R)</button>
      </div>
    </div>
    <div id="viewportWrapper">
      <div class="device-bezel" id="activeDeviceBezel" style="width: 100%; height: 100%; border: 0; border-radius: 0; box-shadow: none; background: transparent;">
        <div class="dynamic-island" id="dynamicIsland" style="display: none;"></div>
        <div class="device-screen" id="deviceScreen">
          <!-- Interactive DOM Elements dynamically mounted -->
        </div>
      </div>
      <div id="debuggerDrawer" class="debugger-drawer" style="display: none;">
        <div class="debugger-header">
          <div class="debugger-tabs">
            <button class="dbg-tab active" data-tab="vars">Variables (<span id="dbgVarCount">0</span>)</button>
            <button class="dbg-tab" data-tab="events">Event Log (<span id="dbgEventCount">0</span>)</button>
          </div>
          <div class="debugger-actions" style="display: flex; gap: 6px;">
            <button class="btn-player" id="btnClearLog" style="padding: 2px 8px; font-size: 10px;">Clear Log</button>
            <button class="btn-player" id="btnCloseDebugger" style="padding: 2px 8px; font-size: 10px;" aria-label="Close debugger"><span data-icon="X"></span></button>
          </div>
        </div>
        <div class="debugger-body">
          <div id="dbgVarsPane" class="dbg-pane active"></div>
          <div id="dbgEventsPane" class="dbg-pane" style="display: none;"></div>
        </div>
      </div>
    </div>
  </div>
  <script>
    window.__DFORGE_DOC__ = ${i};
  <\/script>
  <script>${N}<\/script>
</body>
</html>`}};export{h as a,o as c,r as d,c as f,d as g,l as h,f as i,n as l,t as m,A as n,e as o,s as p,m as r,u as s,I as t,a as u};