/**
 * DesignForge AI - Central AI Service Orchestrator
 * Coordinates providers, context management, pre-flight validation, atomic execution, and diagnostics
 */

import { PROVIDERS, PRIVACY_MODES, ValidationError, CancellationError, ProviderError } from './types.js';
import { ContextManager } from './context.js';
import { OperationValidator } from './validator.js';
import { OperationExecutor } from './operations.js';
import { DesignIntelligenceAnalyzer } from './intelligence.js';
import { LocalProvider } from './providers/local-provider.js';
import { OllamaProvider } from './providers/ollama-provider.js';
import { OpenAIProvider } from './providers/openai-provider.js';
import { GeminiProvider } from './providers/gemini-provider.js';
import { DualReasoningOrchestrator } from './dual_reasoning.js';
import { DesignSystemRepositoryIndexer } from './knowledge/repository_indexer.js';
import { ReactCompiler } from '../engine/compiler.js';

export class DesignForgeAIService {
  constructor(document, commandEngine) {
    this.doc = document;
    this.engine = commandEngine;

    this.contextManager = new ContextManager(document, commandEngine);
    this.validator = new OperationValidator(document);
    this.executor = new OperationExecutor(commandEngine);
    this.intelligence = new DesignIntelligenceAnalyzer(document, commandEngine);
    this.repoIndexer = new DesignSystemRepositoryIndexer(null, document);

    // Active controller for request cancellation
    this.activeAbortController = null;

    // Providers registry
    this.providers = new Map();
    this.registerProvider(new OllamaProvider({ model: 'llama3.1' }));
    this.registerProvider(new LocalProvider());
    this.registerProvider(new OpenAIProvider());
    this.registerProvider(new GeminiProvider());

    this.dualOrchestrator = new DualReasoningOrchestrator(
      this.providers.get(PROVIDERS.OPENAI),
      this.providers.get(PROVIDERS.GEMINI),
      this.providers.get(PROVIDERS.LOCAL)
    );

    for (const provider of this.providers.values()) {
      const savedKey = this.loadSetting(`api_key_${provider.name}`);
      const savedModel = this.loadSetting(`model_${provider.name}`);
      const savedEndpoint = this.loadSetting(`endpoint_${provider.name}`);
      if (savedKey) provider.apiKey = savedKey;
      if (savedModel) provider.model = savedModel;
      if (savedEndpoint) provider.endpoint = savedEndpoint;
    }

    // Load saved settings (defaults to OLLAMA with llama3.1 in browser, LOCAL in headless tests)
    this.activeProviderName = this.loadSetting('ai_active_provider') || (typeof window !== 'undefined' ? PROVIDERS.OLLAMA : PROVIDERS.LOCAL);
    this.privacyMode = this.loadSetting('ai_privacy_mode') || PRIVACY_MODES.LOCAL_ONLY;
    this.contextManager.setPrivacyMode(this.privacyMode);

    this.history = [];
  }

  setRegistry(registry) {
    this.registry = registry;
    if (this.repoIndexer) {
      this.repoIndexer.setRegistryAndDoc(registry, this.doc);
    }
  }

  loadSetting(key) {
    if (typeof localStorage !== 'undefined') {
      return localStorage.getItem(`designforge_${key}`);
    }
    return null;
  }

  saveSetting(key, val) {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(`designforge_${key}`, val);
    }
  }

  registerProvider(provider) {
    this.providers.set(provider.name, provider);
  }

  getProvider(name = this.activeProviderName) {
    if (name === PROVIDERS.AUTO) {
      // Automatic Selection: pick configured hosted provider, or fall back to local
      const gemini = this.providers.get(PROVIDERS.GEMINI);
      const openai = this.providers.get(PROVIDERS.OPENAI);
      if (gemini && gemini.apiKey) return gemini;
      if (openai && openai.apiKey) return openai;
      const ollama = this.providers.get(PROVIDERS.OLLAMA);
      return ollama || this.providers.get(PROVIDERS.LOCAL);
    }
    if (name === PROVIDERS.DUAL) {
      return this.dualOrchestrator;
    }
    return this.providers.get(name) || this.providers.get(PROVIDERS.LOCAL);
  }

  setActiveProvider(name) {
    if (this.providers.has(name) || name === PROVIDERS.AUTO || name === PROVIDERS.DUAL) {
      this.activeProviderName = name;
      this.saveSetting('ai_active_provider', name);
    }
  }

  setProvider(name) {
    return this.setActiveProvider(name);
  }

  setPrivacyMode(mode) {
    this.privacyMode = mode;
    this.contextManager.setPrivacyMode(mode);
    this.saveSetting('ai_privacy_mode', mode);
  }

  configureProvider(name, config, options = {}) {
    const persist = options.persist !== false;
    const provider = this.providers.get(name);
    if (provider) {
      if (config.apiKey !== undefined) {
        provider.apiKey = config.apiKey;
        if (persist) this.saveSetting(`api_key_${name}`, config.apiKey);
      }
      if (config.endpoint !== undefined) {
        provider.endpoint = config.endpoint;
        if (persist) this.saveSetting(`endpoint_${name}`, config.endpoint);
      }
      if (config.model !== undefined) {
        provider.model = config.model;
        if (persist) this.saveSetting(`model_${name}`, config.model);
      }
    }
  }

  clearProviderApiKey(name) {
    const provider = this.providers.get(name);
    if (!provider) throw new Error(`Unknown AI provider "${name}".`);
    provider.apiKey = '';
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem(`designforge_api_key_${name}`);
    }
  }

  /**
   * Cancels any active in-flight generation request
   */
  cancel() {
    if (this.activeAbortController) {
      this.activeAbortController.abort();
      this.activeAbortController = null;
    }
  }

  /**
   * Submits a natural-language request, produces a validated plan, and returns diff
   * @param {string} prompt - User request
   * @param {Function} onProgress - Progress reporter callback
   * @returns {Promise<{ plan: Object, validation: Object }>}
   */
  async plan(prompt, onProgress = null) {
    this.cancel(); // Abort previous if running
    this.activeAbortController = new AbortController();
    const signal = this.activeAbortController.signal;

    // Enforce privacy rule: LOCAL_ONLY allows local built-in and local Ollama
    const isLocalProvider = this.activeProviderName === PROVIDERS.LOCAL || this.activeProviderName === PROVIDERS.OLLAMA;
    if (this.privacyMode === PRIVACY_MODES.LOCAL_ONLY && !isLocalProvider) {
      throw new ProviderError(
        'Local-Only Privacy Mode is active. Switch privacy mode to Allow Hosted or select a Local Provider (Ollama / Built-in).',
        this.activeProviderName
      );
    }

    try {
      // 1. Build compact, relevant context
      const context = this.contextManager.buildContext();

      // Retrieve targeted Design System repository context (Spec Part C)
      const ragContext = this.repoIndexer.retrieveRelevantContext(prompt);
      context.designSystemRepository = ragContext;

      // 2. Check for Code-Aware query
      const lower = prompt.toLowerCase();
      if (lower.startsWith('generate react') || lower.startsWith('explain react') || lower.includes('code export')) {
        return this.handleCodeAwareQuery(prompt, context);
      }

      // 3. Delegate to active provider or dual-reasoning orchestrator
      let rawPlan;
      let activeModelName = 'default';
      let activeProviderLabel = this.activeProviderName;

      if (this.activeProviderName === PROVIDERS.DUAL) {
        rawPlan = await this.dualOrchestrator.reason(prompt, context, { signal, onProgress, ragContext });
        activeModelName = `${rawPlan.models?.openai || 'gpt-4o'} + ${rawPlan.models?.gemini || 'gemini-2.5-pro'}`;
        activeProviderLabel = 'Dual Reasoning (ChatGPT + Gemini)';
      } else {
        const provider = this.getProvider();
        rawPlan = await provider.generate(prompt, context, { signal, onProgress, ragContext });
        activeModelName = provider.model;
        activeProviderLabel = provider.name;
      }

      // 4. Pre-flight strict validation & risk assessment
      const validation = this.validator.validate(rawPlan.operations);
      const riskAssessment = this.validator.assessRisk(rawPlan.operations);
      const diagnosticReport = this.intelligence.audit();
      const validationReport = this.validator.buildValidationReport(validation, diagnosticReport);

      if (!validation.valid) {
        throw new ValidationError(`Proposed operations failed validation:\n${validation.errors.join('\n')}`, validation.errors);
      }

      const verifiedPlan = {
        id: `plan_${Date.now()}`,
        status: riskAssessment.approvalRequired ? 'approval_required' : 'proposed',
        prompt,
        intent: rawPlan.intent || prompt,
        goal: rawPlan.intent || prompt,
        explanation: rawPlan.explanation || 'Design plan synthesized successfully.',
        operations: rawPlan.operations,
        riskLevel: riskAssessment.level,
        approvalRequired: riskAssessment.approvalRequired,
        risks: riskAssessment.reasons,
        validationReport,
        provider: activeProviderLabel,
        model: activeModelName,
        citations: ragContext.citations || [],
        retrievedComponents: ragContext.retrievedComponents || [],
        retrievedTokens: ragContext.retrievedTokens || [],
        dualReasoningAnalysis: rawPlan.dualReasoningAnalysis || null,
        timestamp: new Date().toISOString()
      };

      this.history.push({ prompt, plan: verifiedPlan });
      return { plan: verifiedPlan, validation, validationReport, riskAssessment };
    } finally {
      this.activeAbortController = null;
    }
  }

  /**
   * Applies an approved plan to the document via CommandEngine with Risk Gate
   */
  applyPlan(plan, userApproved = false) {
    if (!plan || !plan.operations) return null;
    const validation = this.validator.validate(plan.operations);
    if (!validation.valid) {
      throw new ValidationError(`Cannot execute invalid operations: ${validation.errors.join(', ')}`);
    }

    const riskAssessment = this.validator.assessRisk(plan.operations);
    if (riskAssessment.approvalRequired && !userApproved) {
      return {
        status: 'blocked',
        approvalRequired: true,
        riskLevel: riskAssessment.level,
        risks: riskAssessment.reasons,
        message: 'Explicit user confirmation required for high-risk operations.'
      };
    }

    const report = this.executor.execute(plan.operations, `AI: ${plan.intent || plan.goal}`);
    const postDiagnostics = this.intelligence.audit();
    report.validationReport = this.validator.buildValidationReport(validation, postDiagnostics);
    report.status = report.errors && report.errors.length > 0 ? 'partial' : 'succeeded';
    return report;
  }


  /**
   * Code-Aware query handler (analyzes React compiler output for current selection)
   */
  handleCodeAwareQuery(prompt, context) {
    const selected = context.selection?.[0];
    const compiler = new ReactCompiler(this.doc);

    let explanation = '';
    if (selected) {
      const page = this.engine.getActivePage();
      const node = page.nodes[selected.id];
      const comp = compiler.compileNodeToComponent(node, page);
      explanation = `### React Analysis for '${selected.name}':\n\n\`\`\`tsx\n${comp.tsx}\n\`\`\`\n\n**Semantics:** Tagged as \`<${node.semanticTag || 'div'}>\` with responsive Auto-Layout.`;
    } else {
      explanation = `### Project React Architecture:\n- Root frame exported as standalone TypeScript component with CSS Modules.\n- Design tokens mapped to \`src/tokens/tokens.ts\`.\n- Zero runtime dependencies required.`;
    }

    return {
      plan: {
        id: `code_${Date.now()}`,
        prompt,
        intent: 'React Code Inspection',
        explanation,
        operations: [],
        provider: 'code-aware-engine'
      },
      validation: { valid: true, errors: [], warnings: [], isDestructive: false }
    };
  }

  /**
   * Queries connected design tokens, guaranteeing no hallucinated token existence
   */
  queryToken(tokenName) {
    if (!this.doc?.tokens) {
      return { found: false, message: `Token "${tokenName}" does not exist: No tokens defined in connected document.` };
    }

    const clean = (str) => String(str || '').replace(/^--token-|^--|^token_/, '').replace(/[\s\/-]+/g, '_').toLowerCase();
    const target = clean(tokenName);

    // 1. Array of token collections (canonical document schema format)
    if (Array.isArray(this.doc.tokens)) {
      for (const col of this.doc.tokens) {
        if (Array.isArray(col.tokens)) {
          for (const t of col.tokens) {
            if (t.id === tokenName || t.name === tokenName || clean(t.id) === target || clean(t.name) === target) {
              return { found: true, category: col.name, name: t.name, id: t.id, value: t.value, type: t.type };
            }
          }
        }
      }
    }

    // 2. Object dictionary format
    if (typeof this.doc.tokens === 'object') {
      for (const [cat, bucket] of Object.entries(this.doc.tokens)) {
        if (bucket && typeof bucket === 'object') {
          for (const [k, v] of Object.entries(bucket)) {
            if (k === tokenName || clean(k) === target) {
              return { found: true, category: cat, name: k, value: v };
            }
          }
        }
      }
    }

    return {
      found: false,
      message: `Token "${tokenName}" does not exist in the connected design system.`
    };
  }

  /**
   * Queries component library with strict permission enforcement
   */
  queryLibrary(libraryId, userPermissions = {}) {
    if (userPermissions[libraryId]?.canRead === false) {
      return {
        allowed: false,
        error: `Permission denied: Read access to library "${libraryId}" is revoked.`
      };
    }
    const components = this.doc?.components || {};
    return {
      allowed: true,
      libraryId,
      components: Object.values(components)
    };
  }

  /**
   * Verifies supported features and formats, identifying limitations honestly
   */
  checkCapability(featureOrFormat) {
    const SUPPORTED = new Set([
      'react-vite-ts',
      'react-vite-js',
      'react-tailwind',
      'react-cssmodules',
      'svg',
      'png',
      'dforge',
      'tokens',
      'prototyping',
      'figma-import',
      'sketch-import'
    ]);

    const normalized = String(featureOrFormat).toLowerCase().trim();
    if (SUPPORTED.has(normalized)) {
      return { supported: true, capability: normalized };
    }

    return {
      supported: false,
      limitation: `Capability "${featureOrFormat}" is not supported. Supported targets: React 18 + Vite (TypeScript/JavaScript), SVG, PNG, and .dforge bundles.`
    };
  }

  /**
   * Generates a wireframe element, transparently marking components not in the design system
   */
  generateWireframe(nodeSpec, options = {}) {
    const existingComponents = this.doc?.components || {};
    const matchingComp = Object.values(existingComponents).find(c => 
      c.name?.toLowerCase() === (nodeSpec.name || '').toLowerCase()
    );

    if (matchingComp) {
      return {
        ...nodeSpec,
        type: 'instance',
        componentId: matchingComp.id,
        systemStatus: 'linked_to_design_system'
      };
    }

    // Agent Master Prompt Section 9, Acceptance Test #2:
    // Mark new assets transparently as 'new_not_in_connected_design_system'
    return {
      ...nodeSpec,
      systemStatus: 'new_not_in_connected_design_system'
    };
  }

  /**
   * Comprehensive WCAG audit that distinguishes automated checks from full WCAG compliance
   */
  auditAccessibility() {
    const auditReport = this.intelligence.audit();
    const validation = { valid: true, errors: [], warnings: [] };
    const report = this.validator.buildValidationReport(validation, auditReport);

    return {
      ...report,
      complianceStatement: 'Automated contrast audit executed. Note: Automated checks alone do not establish full WCAG 2.2 AA/AAA compliance; manual screen-reader, keyboard traps, and assistive technology testing are required.',
      limitations: [
        'Screen-reader accessibility trees are generated during code compilation, not in raw canvas shapes.',
        'Audio/video media alternatives require manual content verification.'
      ]
    };
  }

  /**
   * Audits the active document for design flaws, contrast issues, and layout bugs
   */
  auditDocument() {
    return this.intelligence.audit();
  }
}
