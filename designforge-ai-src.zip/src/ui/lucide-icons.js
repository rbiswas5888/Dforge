import { createElement } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Activity,
  Accessibility,
  AlignCenter,
  ArrowLeftRight,
  ArrowDown,
  ArrowDownToLine,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ArrowUpDown,
  ArrowUpRight,
  Bell,
  Bot,
  BookOpen,
  Bug,
  Box,
  Building2,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChartNoAxesColumn,
  Circle,
  CircleHelp,
  Clock3,
  Code2,
  Contrast,
  Copy,
  CreditCard,
  Crop,
  Download,
  Eye,
  EyeOff,
  FileText,
  Flag,
  Folder,
  Frame,
  Gem,
  GitBranch,
  Globe,
  Hand,
  History,
  Image,
  Info,
  KeyRound,
  Layers,
  LayoutDashboard,
  Lightbulb,
  Keyboard,
  Link,
  LockKeyhole,
  LockOpen,
  LogOut,
  MapPin,
  Menu,
  MessageSquare,
  Minus,
  Monitor,
  Moon,
  MousePointer2,
  Paintbrush,
  Palette,
  PanelLeftClose,
  PanelRight,
  PenTool,
  Pencil,
  Pin,
  Pipette,
  Play,
  Plus,
  Redo2,
  Ruler,
  RotateCcw,
  Save,
  Search,
  Settings,
  Share2,
  ShieldCheck,
  Scaling,
  SlidersHorizontal,
  Sparkles,
  Square,
  SquareDashed,
  Star,
  Sun,
  Tablet,
  ShoppingCart,
  Target,
  Triangle,
  TriangleAlert,
  Trash2,
  Type,
  Undo2,
  Upload,
  UserRound,
  UsersRound,
  WandSparkles,
  Wrench,
  X,
  Zap,
  ZoomIn,
  ZoomOut
} from 'lucide-react';

const GoogleIcon = (props) => createElement('svg', {
  viewBox: '0 0 24 24',
  width: props.size || 16,
  height: props.size || 16,
  fill: 'none',
  xmlns: 'http://www.w3.org/2000/svg',
  ...props
}, [
  createElement('path', {
    key: 'p1',
    d: 'M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z',
    fill: '#4285F4'
  }),
  createElement('path', {
    key: 'p2',
    d: 'M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z',
    fill: '#34A853'
  }),
  createElement('path', {
    key: 'p3',
    d: 'M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z',
    fill: '#FBBC05'
  }),
  createElement('path', {
    key: 'p4',
    d: 'M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z',
    fill: '#EA4335'
  })
]);

const icons = {
  Chrome: GoogleIcon,
  Activity,
  Accessibility,
  AlignCenter,
  ArrowLeftRight,
  ArrowDown,
  ArrowDownToLine,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ArrowUpDown,
  ArrowUpRight,
  Bell,
  Bot,
  BookOpen,
  Bug,
  Box,
  Building2,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChartNoAxesColumn,
  Circle,
  CircleHelp,
  Clock3,
  Code2,
  Contrast,
  Copy,
  CreditCard,
  Crop,
  Download,
  Eye,
  EyeOff,
  FileText,
  Flag,
  Folder,
  Frame,
  Gem,
  GitBranch,
  Globe,
  Hand,
  History,
  Image,
  Info,
  KeyRound,
  Layers,
  LayoutDashboard,
  Lightbulb,
  Keyboard,
  Link,
  LockKeyhole,
  LockOpen,
  LogOut,
  MapPin,
  Menu,
  MessageSquare,
  Minus,
  Monitor,
  Moon,
  MousePointer2,
  Paintbrush,
  Palette,
  PanelLeftClose,
  PanelRight,
  PenTool,
  Pencil,
  Pin,
  Pipette,
  Play,
  Plus,
  Redo2,
  Ruler,
  RotateCcw,
  Save,
  Search,
  Settings,
  Share2,
  ShieldCheck,
  Scaling,
  SlidersHorizontal,
  Sparkles,
  Square,
  SquareDashed,
  Star,
  Sun,
  Tablet,
  ShoppingCart,
  Target,
  Triangle,
  TriangleAlert,
  Trash2,
  Type,
  Undo2,
  Upload,
  UserRound,
  UsersRound,
  WandSparkles,
  Wrench,
  X,
  Zap,
  ZoomIn,
  ZoomOut
};

const mountedRoots = new WeakMap();

function mountIcon(element) {
  const Icon = icons[element.dataset.icon];
  if (!Icon) {
    console.error(`Unknown Lucide icon: ${element.dataset.icon}`);
    return;
  }

  const size = Number(element.dataset.iconSize) || 16;
  element.classList.add('app-icon');
  element.setAttribute('aria-hidden', 'true');
  element.style.setProperty('--icon-size', `${size}px`);
  let root = mountedRoots.get(element);
  if (!root) {
    root = createRoot(element);
    mountedRoots.set(element, root);
  }
  root.render(createElement(Icon, {
    size,
    strokeWidth: 1.8,
    focusable: false
  }));
}

export function mountLucideIcons(container = document.body) {
  const scan = node => {
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    if (node.matches('[data-icon]') && !mountedRoots.has(node)) mountIcon(node);
    node.querySelectorAll('[data-icon]').forEach(element => {
      if (!mountedRoots.has(element)) mountIcon(element);
    });
  };

  scan(container);
  const observer = new MutationObserver(records => {
    records.forEach(record => {
      if (record.type === 'attributes') {
        mountIcon(record.target);
        return;
      }
      record.addedNodes.forEach(scan);
    });
  });
  observer.observe(container, { attributes: true, attributeFilter: ['data-icon'], childList: true, subtree: true });

  return () => {
    observer.disconnect();
    container.querySelectorAll('[data-icon]').forEach(element => {
      mountedRoots.get(element)?.unmount();
      mountedRoots.delete(element);
    });
  };
}
