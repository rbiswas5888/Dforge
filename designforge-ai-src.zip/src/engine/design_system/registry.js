/**
 * DesignForge AI — Unified Design System Subsystem
 * Central Authoritative Design System Registry
 * Conforms to Master Specification Section 3, 4, 8, 17
 */

import {
  createDesignSystem,
  createToken,
  createVariable,
  createStyleDef,
  createComponentDef,
  createAssetRecord,
  exportToDTCGFormat,
  importFromDTCGFormat,
  TOKEN_CATEGORIES,
  VARIABLE_TYPES,
  STYLE_CATEGORIES,
  THEME_MODES,
  DESIGN_SYSTEM_STARTERS,
  generateDSId
} from './types.js';

export class DesignSystemRegistry {
  constructor(documentModel = null, storageEngine = null) {
    this.doc = documentModel;
    this.storage = storageEngine;
    this.system = this.loadOrCreateSystem();
  }

  getAllTokens() {
    return Object.values(this.system.tokens || {});
  }

  getAllVariables() {
    return Object.values(this.system.variables || {});
  }

  getAllComponents() {
    return Object.values(this.system.components || {});
  }

  getAllStyles() {
    return Object.values(this.system.styles || {});
  }

  getTokensByTier(tier) {
    const t = String(tier || '').toLowerCase();
    return this.getAllTokens().filter(token => (token.tier || (token.isSemantic ? 'semantic' : 'primitive')) === t);
  }

  getVariablesByType(type) {
    const target = String(type || '').toLowerCase();
    return this.getAllVariables().filter(v => (v.type || '').toLowerCase() === target);
  }

  getVariablesByScope(scope) {
    const target = String(scope || '').toLowerCase();
    return this.getAllVariables().filter(v => {
      const scopes = Array.isArray(v.scopes) ? v.scopes : ['all'];
      return scopes.includes('all') || scopes.includes(target);
    });
  }

  setTokenCodeSyntax(tokenId, syntaxObj) {
    const token = this.system.tokens[tokenId];
    if (!token) return null;
    token.codeSyntax = { ...(token.codeSyntax || {}), ...syntaxObj };
    token.updatedAt = new Date().toISOString();
    this.persist();
    return token;
  }

  setVariableCodeSyntax(varId, syntaxObj) {
    const variable = this.system.variables[varId];
    if (!variable) return null;
    variable.codeSyntax = { ...(variable.codeSyntax || {}), ...syntaxObj };
    variable.updatedAt = new Date().toISOString();
    this.persist();
    return variable;
  }

  getDependents(tokenId) {
    return this.findTokenDependents(tokenId);
  }

  initializeWithStarter(starter, name, description) {
    const starterKey = String(starter || DESIGN_SYSTEM_STARTERS.MINIMAL).toLowerCase();
    const validStarters = new Set([
      DESIGN_SYSTEM_STARTERS.BLANK,
      DESIGN_SYSTEM_STARTERS.MINIMAL,
      DESIGN_SYSTEM_STARTERS.ENTERPRISE,
      DESIGN_SYSTEM_STARTERS.FINTECH,
      DESIGN_SYSTEM_STARTERS.ECOMMERCE,
      DESIGN_SYSTEM_STARTERS.MATERIAL,
      DESIGN_SYSTEM_STARTERS.HEALTHCARE,
      DESIGN_SYSTEM_STARTERS.EDUCATION
    ]);
    if (!validStarters.has(starterKey)) {
      throw new Error(`Unknown design system starter: ${starter}`);
    }

    this.system.name = String(name || 'New Design System').trim() || 'New Design System';
    if (description !== undefined) {
      this.system.description = String(description).trim();
    }
    this.system.status = 'draft';
    this.system.updatedAt = new Date().toISOString();
    if (starterKey !== DESIGN_SYSTEM_STARTERS.BLANK) {
      const collectionName = `${this.system.name} Foundations`;
      let collection = this.system.collections.find(item => item.name === collectionName);
      if (!collection) {
        collection = { id: generateDSId('col'), name: collectionName };
        this.system.collections.push(collection);
      }

      const seedColors = {
        minimal: [['Color / Primary', '#2563eb'], ['Color / Surface', '#ffffff'], ['Color / Text', '#0f172a']],
        enterprise: [['Color / Primary', '#1d4ed8'], ['Color / Surface', '#f8fafc'], ['Color / Text', '#0f172a']],
        fintech: [['Color / Primary', '#0f766e'], ['Color / Surface', '#f8fafc'], ['Color / Text', '#0f172a'], ['Color / Gain', '#10b981'], ['Color / Loss', '#ef4444']],
        ecommerce: [['Color / Primary', '#db2777'], ['Color / Surface', '#fff7ed'], ['Color / Text', '#1f2937']],
        material: [['Color / Primary', '#6750a4'], ['Color / Surface', '#fffbfe'], ['Color / Text', '#1d1b20']],
        healthcare: [['Color / Primary', '#0284c7'], ['Color / Surface', '#f0f9ff'], ['Color / Text', '#082f49'], ['Color / Safe', '#16a34a'], ['Color / Warning', '#d97706'], ['Color / Alert', '#dc2626']],
        education: [['Color / Primary', '#7c3aed'], ['Color / Surface', '#fbfbfe'], ['Color / Text', '#1e1b4b'], ['Color / Progress', '#059669'], ['Color / Feedback', '#ea580c']]
      }[starterKey] || [];
      for (const [tokenName, value] of seedColors) {
        if (!this.getAllTokens().some(token => token.name.toLowerCase() === tokenName.toLowerCase())) {
          this.addToken(TOKEN_CATEGORIES.COLOR, tokenName, value, {
            collectionId: collection.id
          });
        }
      }
    }

    this.syncDocTokensArray();
    this.persist();
    return this.system;
  }

  loadOrCreateSystem() {
    // If document already embeds a design system model, load it
    if (this.doc && this.doc.designSystem) {
      const ds = this.doc.designSystem;
      ds.collections ||= [];
      ds.tokens ||= {};
      ds.variables ||= {};
      ds.components ||= {};
      ds.styles ||= {};
      ds.assets ||= {};
      ds.history ||= [];
      ds.importJobs ||= [];
      this.migrateLegacyDocTokens(ds);
      return ds;
    }

    // Initialize clean default system with existing document tokens migrated
    const ds = createDesignSystem('DesignForge Core System');
    this.migrateLegacyDocTokens(ds);
    if (this.doc) {
      this.doc.designSystem = ds;
    }
    return ds;
  }

  /**
   * Safe migration of legacy doc.tokens array into unified registry
   */
  migrateLegacyDocTokens(ds) {
    if (!this.doc || !this.doc.tokens) return;
    for (const group of this.doc.tokens) {
      const collectionId = group.id || `col_${group.name.toLowerCase().replace(/\s+/g, '_')}`;
      if (!ds.collections.some(c => c.id === collectionId)) {
        ds.collections.push({ id: collectionId, name: group.name });
      }

      for (const t of group.tokens || []) {
        if (!ds.tokens[t.id]) {
          const tok = createToken(t.type || 'color', t.name, t.value, {
            id: t.id,
            collectionId
          });
          ds.tokens[t.id] = tok;

          // Auto-sync into Assets view
          this.syncToAsset(ds, 'token', tok.name, tok.id, tok.category);

          // Auto-sync into Variables view
          if (!ds.variables[t.id]) {
            const varType = t.type === 'color' ? VARIABLE_TYPES.COLOR : VARIABLE_TYPES.DIMENSION;
            const variable = createVariable(tok.name, varType, tok.value, {
              id: `var_${t.id}`,
              linkedTokenId: tok.id,
              collectionId
            });
            ds.variables[variable.id] = variable;
            this.syncToAsset(ds, 'variable', variable.name, variable.id, variable.type);
          }
        }
      }
    }
  }

  // --- Automatic Synchronization & Registry Rules (Section 8) ---

  syncToAsset(ds, type, name, sourceId, category = 'General') {
    const existingAssetKey = Object.keys(ds.assets).find(
      k => ds.assets[k].sourceId === sourceId && ds.assets[k].type === type
    );

    if (existingAssetKey) {
      ds.assets[existingAssetKey].name = name;
      ds.assets[existingAssetKey].category = category;
    } else {
      const asset = createAssetRecord(type, name, { sourceId, category });
      ds.assets[asset.id] = asset;
    }
  }

  removeFromAsset(ds, sourceId) {
    for (const assetId of Object.keys(ds.assets)) {
      if (ds.assets[assetId].sourceId === sourceId) {
        delete ds.assets[assetId];
      }
    }
  }

  // --- Tokens CRUD ---

  addToken(category, name, value, options = {}) {
    const token = createToken(category, name, value, options);
    this.system.tokens[token.id] = token;
    this.system.updatedAt = new Date().toISOString();

    // Auto-sync to Assets inventory
    this.syncToAsset(this.system, 'token', token.name, token.id, token.category);

    // Keep doc.tokens synced for backwards compatibility with compiler and renderer
    this.syncDocTokensArray();
    this.persist();
    return token;
  }

  updateToken(id, updates = {}) {
    const token = this.system.tokens[id];
    if (!token) throw new Error(`Token ${id} not found.`);

    Object.assign(token, updates);
    token.updatedAt = new Date().toISOString();
    this.system.updatedAt = token.updatedAt;

    // Update Asset projection
    this.syncToAsset(this.system, 'token', token.name, token.id, token.category);

    // If a linked variable exists, propagate value
    for (const varId of Object.keys(this.system.variables)) {
      const v = this.system.variables[varId];
      if (v.linkedTokenId === id && updates.value !== undefined) {
        v.value = updates.value;
        v.updatedAt = token.updatedAt;
      }
    }

    this.syncDocTokensArray();
    this.persist();
    return token;
  }

  deleteToken(id, replacementTokenId = null) {
    const token = this.system.tokens[id];
    if (!token) return false;

    // Dependents validation: check if components or nodes reference this token
    const dependents = this.findTokenDependents(id);
    if (dependents.length > 0 && !replacementTokenId) {
      throw new Error(`Cannot delete token "${token.name}": referenced by ${dependents.length} layer(s). Specify a replacement token.`);
    }

    // Rebind dependents to replacement if provided
    if (replacementTokenId && this.system.tokens[replacementTokenId]) {
      this.rebindDependents(id, replacementTokenId);
    }

    delete this.system.tokens[id];
    this.removeFromAsset(this.system, id);
    this.syncDocTokensArray();
    this.persist();
    return true;
  }

  // --- Variables CRUD ---

  addVariable(name, type, value, options = {}) {
    const variable = createVariable(name, type, value, options);
    this.system.variables[variable.id] = variable;
    this.system.updatedAt = new Date().toISOString();

    this.syncToAsset(this.system, 'variable', variable.name, variable.id, variable.type);
    this.persist();
    return variable;
  }

  createVariable(name, type, value, options = {}) {
    return this.addVariable(name, type, value, options);
  }

  updateVariable(id, updates = {}) {
    const v = this.system.variables[id];
    if (!v) throw new Error(`Variable ${id} not found.`);

    Object.assign(v, updates);
    v.updatedAt = new Date().toISOString();
    this.system.updatedAt = v.updatedAt;

    this.syncToAsset(this.system, 'variable', v.name, v.id, v.type);
    this.persist();
    return v;
  }

  deleteVariable(id) {
    if (!this.system.variables[id]) return false;
    delete this.system.variables[id];
    this.removeFromAsset(this.system, id);
    this.persist();
    return true;
  }

  // --- Components CRUD ---

  registerComponent(name, options = {}) {
    const comp = createComponentDef(name, options);
    this.system.components[comp.id] = comp;
    this.system.updatedAt = new Date().toISOString();

    this.syncToAsset(this.system, 'component', comp.name, comp.id, comp.category);
    this.persist();
    return comp;
  }

  // --- Styles CRUD (Figma 5 Native Style Categories) ---

  addStyle(nameOrStyle, category, properties = {}, options = {}) {
    const style = (typeof nameOrStyle === 'object' && nameOrStyle !== null && nameOrStyle.id)
      ? nameOrStyle
      : createStyleDef(nameOrStyle, category, properties, options);
    this.system.styles[style.id] = style;
    this.system.updatedAt = new Date().toISOString();

    this.syncToAsset(this.system, 'style', style.name, style.id, style.category);
    this.persist();
    return style;
  }

  getStyle(idOrName) {
    if (this.system.styles[idOrName]) return this.system.styles[idOrName];
    return Object.values(this.system.styles).find(s => s.name === idOrName) || null;
  }

  getStylesByCategory(category) {
    const cat = String(category || '').toLowerCase();
    return Object.values(this.system.styles).filter(s => (s.category || '').toLowerCase() === cat);
  }

  updateStyle(id, updates = {}) {
    const style = this.system.styles[id];
    if (!style) throw new Error(`Style ${id} not found.`);

    Object.assign(style, updates);
    style.updatedAt = new Date().toISOString();
    this.system.updatedAt = style.updatedAt;

    this.syncToAsset(this.system, 'style', style.name, style.id, style.category);
    this.persist();
    return style;
  }

  deleteStyle(id) {
    if (!this.system.styles[id]) return false;
    delete this.system.styles[id];
    this.removeFromAsset(this.system, id);
    this.persist();
    return true;
  }

  // --- DTCG (Design Tokens Community Group) Interoperability ---

  exportToDTCG() {
    return exportToDTCGFormat(this);
  }

  importFromDTCG(dtcgJson) {
    const tokens = importFromDTCGFormat(dtcgJson);
    const added = [];
    for (const t of tokens) {
      this.system.tokens[t.id] = t;
      this.syncToAsset(this.system, 'token', t.name, t.id, t.category);
      added.push(t);
    }
    if (dtcgJson?.styles) {
      for (const [name, def] of Object.entries(dtcgJson.styles)) {
        const ext = def.$extensions?.['com.designforge'] || {};
        const style = createStyleDef(
          name,
          ext.category || def.$type || STYLE_CATEGORIES.COLOR,
          ext.properties || (typeof def.$value === 'object' ? def.$value : { value: def.$value }),
          {
            id: ext.id,
            description: def.$description || '',
            codeSyntax: ext.codeSyntax,
            modeOverrides: ext.modeOverrides
          }
        );
        this.addStyle(style);
      }
    }
    this.system.updatedAt = new Date().toISOString();
    this.syncDocTokensArray();
    this.persist();
    return added;
  }

  updateComponent(id, updates = {}) {
    const comp = this.system.components[id];
    if (!comp) throw new Error(`Component ${id} not found.`);

    Object.assign(comp, updates);
    comp.updatedAt = new Date().toISOString();
    this.system.updatedAt = comp.updatedAt;

    this.syncToAsset(this.system, 'component', comp.name, comp.id, comp.category);
    this.persist();
    return comp;
  }

  // --- Live Computed Overview Metrics (Section 4) ---

  computeOverviewMetrics() {
    const tokens = Object.values(this.system.tokens);
    const variables = Object.values(this.system.variables);
    const components = Object.values(this.system.components);
    const assets = Object.values(this.system.assets);

    // Compute variants count
    let totalVariants = 0;
    for (const c of components) {
      totalVariants += (c.variants || []).length;
    }

    // Detect duplicates (e.g., exact same hex color or spacing across multiple tokens)
    const duplicateCandidates = [];
    const valMap = new Map();
    for (const t of tokens) {
      const key = `${t.category}:${t.value}`;
      if (valMap.has(key)) {
        duplicateCandidates.push({
          tokenA: valMap.get(key),
          tokenB: t,
          value: t.value,
          category: t.category
        });
      } else {
        valMap.set(key, t);
      }
    }

    // Detect raw unbound values in the document model
    let unboundCount = 0;
    if (this.doc && this.doc.pages) {
      for (const p of this.doc.pages) {
        for (const n of Object.values(p.nodes || {})) {
          if (!n.tokenBindings || Object.keys(n.tokenBindings).length === 0) {
            if (n.style?.fills?.length > 0) unboundCount++;
          }
        }
      }
    }

    // Unused items
    const unusedTokens = tokens.filter(t => t.usageCount === 0);

    return {
      totalTokens: tokens.length,
      totalVariables: variables.length,
      totalComponents: components.length,
      totalVariants,
      totalStyles: Object.keys(this.system.styles).length,
      totalAssets: assets.length,
      activeMode: this.system.activeMode,
      version: this.system.version,
      duplicateCandidatesCount: duplicateCandidates.length,
      duplicateCandidates,
      unboundCount,
      unusedCount: unusedTokens.length,
      unusedTokens,
      status: this.system.status
    };
  }

  // --- Themes & Modes (Section 5.3) ---

  setActiveMode(mode) {
    if (!this.system.modes.includes(mode)) {
      this.system.modes.push(mode);
    }
    this.system.activeMode = mode;
    this.persist();
  }

  getResolvedTokenValue(tokenId, mode = null) {
    const token = this.system.tokens[tokenId];
    if (!token) return null;
    const targetMode = mode || this.system.activeMode;

    if (token.modeOverrides && token.modeOverrides[targetMode]) {
      const overrideVal = token.modeOverrides[targetMode];
      if (overrideVal.startsWith('tok_') && this.system.tokens[overrideVal]) {
        return this.getResolvedTokenValue(overrideVal, targetMode);
      }
      return overrideVal;
    }

    if (token.refId && this.system.tokens[token.refId]) {
      return this.getResolvedTokenValue(token.refId, targetMode);
    }

    return token.value;
  }

  // --- Versioning & Publication (Section 17) ---

  publishRelease(versionTag, changeSummary = 'Release publish') {
    const release = {
      id: generateDSId('rel'),
      version: versionTag || this.system.version,
      publishedAt: new Date().toISOString(),
      summary: changeSummary,
      snapshot: {
        tokenCount: Object.keys(this.system.tokens).length,
        variableCount: Object.keys(this.system.variables).length,
        componentCount: Object.keys(this.system.components).length
      }
    };

    this.system.version = versionTag;
    this.system.status = 'published';
    this.system.history.unshift(release);
    this.persist();
    return release;
  }

  // --- Dependency Graph Helpers ---

  findTokenDependents(tokenId) {
    const deps = [];
    if (!this.doc || !this.doc.pages) return deps;
    for (const page of this.doc.pages) {
      for (const [nodeId, node] of Object.entries(page.nodes || {})) {
        if (node.tokenBindings) {
          for (const [prop, bindingTokId] of Object.entries(node.tokenBindings)) {
            if (bindingTokId === tokenId) {
              deps.push({ nodeId, nodeName: node.name, pageId: page.id, property: prop });
            }
          }
        }
      }
    }
    return deps;
  }

  rebindDependents(oldTokenId, newTokenId) {
    if (!this.doc || !this.doc.pages) return;
    for (const page of this.doc.pages) {
      for (const node of Object.values(page.nodes || {})) {
        if (node.tokenBindings) {
          for (const [prop, bindingTokId] of Object.entries(node.tokenBindings)) {
            if (bindingTokId === oldTokenId) {
              node.tokenBindings[prop] = newTokenId;
            }
          }
        }
      }
    }
  }

  syncDocTokensArray() {
    if (!this.doc) return;
    const collectionsMap = new Map();

    for (const t of Object.values(this.system.tokens)) {
      const colId = t.collectionId || 'collection_default';
      if (!collectionsMap.has(colId)) {
        const colDef = this.system.collections.find(c => c.id === colId);
        collectionsMap.set(colId, {
          id: colId,
          name: colDef ? colDef.name : 'General Tokens',
          tokens: []
        });
      }
      collectionsMap.get(colId).tokens.push({
        id: t.id,
        name: t.name,
        type: t.type,
        value: this.getResolvedTokenValue(t.id)
      });
    }

    this.doc.tokens = Array.from(collectionsMap.values());
  }

  persist() {
    if (this.storage && this.doc) {
      if (typeof this.storage.scheduleAutosave !== 'function') {
        throw new Error('Design system persistence requires a storage engine with scheduleAutosave().');
      }
      this.storage.scheduleAutosave(this.doc);
    }
  }
}
