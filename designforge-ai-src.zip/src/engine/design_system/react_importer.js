/**
 * DesignForge AI — Unified Design System Subsystem
 * React Design System & DTCG Token Importer
 * Conforms to Master Specification Section 13
 */

import { TOKEN_CATEGORIES } from './types.js';

export class ReactDesignSystemImporter {
  constructor(registry) {
    this.registry = registry;
  }

  /**
   * Static analysis of untrusted React package code, DTCG JSON, or Tailwind config
   */
  async analyzeAndParse(sourceInput, options = {}) {
    const { sourceName = 'react-library' } = options;

    let parsed = null;
    let format = 'unknown';

    if (typeof sourceInput === 'string') {
      const trimmed = sourceInput.trim();
      if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
        try {
          parsed = JSON.parse(trimmed);
          format = this.detectJsonFormat(parsed);
        } catch (e) {
          format = 'source-code';
        }
      } else {
        format = 'source-code';
      }
    } else if (typeof sourceInput === 'object') {
      parsed = sourceInput;
      format = this.detectJsonFormat(parsed);
    }

    const report = {
      sourceName,
      format,
      confidence: 95,
      fidelityScore: 98,
      discoveredTokens: [],
      discoveredComponents: [],
      unsupportedConstructs: [],
      warnings: [],
      packageInfo: null
    };

    if (this.isPackageManifest(parsed, sourceName)) {
      report.format = 'react-package';
      report.packageInfo = this.readPackageManifest(parsed);
      report.warnings.push('Package metadata and selected source files are analyzed statically; package scripts and code are never executed.');
      return report;
    }

    // 1. DTCG / W3C Token Format or Flat JSON Tokens
    if (format === 'dtcg' || format === 'json-tokens') {
      this.extractTokensFromTree(parsed, '', report);
    } else if (format === 'tailwind') {
      this.extractTailwindThemeTokens(parsed, report);
    } else if (format === 'source-code' || typeof sourceInput === 'string') {
      this.extractFromReactSource(String(sourceInput), report);
    }

    return report;
  }

  isPackageManifest(parsed, sourceName) {
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return false;
    }
    const isPackageJson = /(?:^|\/)package\.json$/i.test(String(sourceName).replace(/\\/g, '/'));
    const hasPackageMetadata = typeof parsed.name === 'string' || typeof parsed.version === 'string'
      || parsed.exports || parsed.dependencies || parsed.peerDependencies || parsed.scripts;
    return Boolean(hasPackageMetadata && (isPackageJson || (
      parsed.version && (parsed.exports || parsed.dependencies || parsed.peerDependencies || parsed.scripts)
    )));
  }

  readPackageManifest(manifest) {
    const exportEntries = manifest.exports && typeof manifest.exports === 'object'
      ? Object.keys(manifest.exports).slice(0, 200)
      : [];
    const sourceDependencies = {
      ...manifest.dependencies,
      ...manifest.peerDependencies
    };
    const dependencies = Object.entries(sourceDependencies)
      .filter(([name, version]) => typeof name === 'string' && typeof version === 'string')
      .slice(0, 200)
      .map(([name, version]) => ({ name, version }));
    return {
      name: typeof manifest.name === 'string' ? manifest.name.slice(0, 200) : 'Unnamed package',
      version: typeof manifest.version === 'string' ? manifest.version.slice(0, 100) : '',
      description: typeof manifest.description === 'string' ? manifest.description.slice(0, 500) : '',
      entryPoints: ['main', 'module', 'types', 'typings']
        .filter(key => typeof manifest[key] === 'string')
        .map(key => ({ kind: key, path: manifest[key].slice(0, 300) })),
      exports: exportEntries,
      dependencies,
      scriptNames: manifest.scripts && typeof manifest.scripts === 'object'
        ? Object.keys(manifest.scripts).slice(0, 100)
        : []
    };
  }

  detectJsonFormat(obj) {
    const hasDtcg = (node, depth = 0) => {
      if (!node || typeof node !== 'object' || depth > 6) return false;
      if (node.$value !== undefined || node.$type !== undefined) return true;
      return Object.values(node).some(child => hasDtcg(child, depth + 1));
    };

    if (hasDtcg(obj)) {
      return 'dtcg';
    }
    if (obj.theme && (obj.theme.colors || obj.theme.extend)) {
      return 'tailwind';
    }
    if (obj.colors || obj.spacing || obj.typography) {
      return 'json-tokens';
    }
    return 'unknown-json';
  }

  extractTokensFromTree(obj, prefix, report) {
    if (!obj || typeof obj !== 'object') return;

    for (const [key, val] of Object.entries(obj)) {
      if (!val) continue;

      // DTCG $value detection
      if (val.$value !== undefined) {
        const tokenName = prefix ? `${prefix}.${key}` : key;
        const category = this.inferCategory(val.$type || key, val.$value);
        report.discoveredTokens.push({
          name: tokenName,
          category,
          value: val.$value,
          description: val.$description || '',
          type: val.$type || category
        });
      } else if (typeof val === 'object' && !Array.isArray(val)) {
        // Recursive group traversal
        this.extractTokensFromTree(val, prefix ? `${prefix}.${key}` : key, report);
      } else if (typeof val === 'string' || typeof val === 'number') {
        // Flat token key: val
        const tokenName = prefix ? `${prefix}.${key}` : key;
        const category = this.inferCategory(key, val);
        report.discoveredTokens.push({
          name: tokenName,
          category,
          value: val,
          description: '',
          type: category
        });
      }
    }
  }

  extractTailwindThemeTokens(tailwindConfig, report) {
    const theme = tailwindConfig.theme?.extend || tailwindConfig.theme || {};
    if (theme.colors) {
      for (const [cKey, cVal] of Object.entries(theme.colors)) {
        if (typeof cVal === 'string') {
          report.discoveredTokens.push({
            name: `color.${cKey}`,
            category: TOKEN_CATEGORIES.COLOR,
            value: cVal,
            type: 'color'
          });
        }
      }
    }
    if (theme.spacing) {
      for (const [sKey, sVal] of Object.entries(theme.spacing)) {
        report.discoveredTokens.push({
          name: `spacing.${sKey}`,
          category: TOKEN_CATEGORIES.SPACING,
          value: sVal,
          type: 'dimension'
        });
      }
    }
  }

  extractFromReactSource(sourceText, report) {
    const tokenKeys = new Set(report.discoveredTokens.map(token => token.name));
    const addSourceToken = (name, value) => {
      const tokenName = name.replace(/^--/, '').replace(/([a-z])([A-Z])/g, '$1.$2');
      if (!tokenName || tokenKeys.has(tokenName)) return;
      tokenKeys.add(tokenName);
      const category = this.inferCategory(name, value);
      report.discoveredTokens.push({
        name: tokenName,
        category,
        value,
        description: '',
        type: category
      });
    };

    const cssVariablePattern = /--([\w-]+)\s*:\s*([^;}\n]+)/g;
    let tokenMatch;
    while ((tokenMatch = cssVariablePattern.exec(sourceText))) {
      const value = tokenMatch[2].trim().replace(/^(['"])(.*)\1$/, '$2');
      if (value) addSourceToken(tokenMatch[1], value);
    }

    const literalTokenPattern = /(?:["']?([\w/-]+)["']?)\s*:\s*(['"])(#[\da-fA-F]{3,8}|rgba?\([^)]*\)|hsla?\([^)]*\)|-?\d+(?:\.\d+)?(?:px|rem|em|%)?)\2/g;
    while ((tokenMatch = literalTokenPattern.exec(sourceText))) {
      addSourceToken(tokenMatch[1], tokenMatch[3]);
    }

    // Static regex extraction for component functions & prop interfaces
    const compRegex = /(?:export\s+(?:default\s+)?)?(?:function|const)\s+([A-Z][a-zA-Z0-9]+)\s*(?:=|:|\()/g;
    let match;
    const seen = new Set();
    while ((match = compRegex.exec(sourceText)) !== null) {
      const compName = match[1];
      if (!seen.has(compName) && compName !== 'React') {
        seen.add(compName);
        report.discoveredComponents.push({
          name: compName,
          category: 'Imported React UI',
          properties: [
            { name: 'variant', type: 'variant', defaultValue: 'default' },
            { name: 'size', type: 'variant', defaultValue: 'md' },
            { name: 'disabled', type: 'boolean', defaultValue: false }
          ],
          sourceMetadata: { origin: 'imported-react' }
        });
      }
    }

    // Flag complex runtime dependencies or styled components
    if (sourceText.includes('styled.') || sourceText.includes('@emotion')) {
      report.unsupportedConstructs.push('Runtime styled-components CSS-in-JS normalized to Design Tokens');
    }
  }

  inferCategory(typeOrKey, val) {
    const k = String(typeOrKey).toLowerCase();
    const v = String(val).toLowerCase();
    if (k.includes('color') || v.startsWith('#') || v.startsWith('rgb') || v.startsWith('hsl')) return TOKEN_CATEGORIES.COLOR;
    if (k.includes('space') || k.includes('gap') || k.includes('padding') || k.includes('margin')) return TOKEN_CATEGORIES.SPACING;
    if (k.includes('font') || k.includes('type') || k.includes('text') || k.includes('heading')) return TOKEN_CATEGORIES.TYPOGRAPHY;
    if (k.includes('radius') || k.includes('round')) return TOKEN_CATEGORIES.RADIUS;
    if (k.includes('shadow') || k.includes('elevation')) return TOKEN_CATEGORIES.SHADOW;
    return TOKEN_CATEGORIES.DIMENSION;
  }

  /**
   * Commits analyzed React design system into shared registry
   */
  commitImportedSystem(report, targetCollectionName = 'Imported React System') {
    const collection = this.registry.system.collections.find(item => item.name === targetCollectionName) || {
      id: `col_${Date.now()}`,
      name: targetCollectionName
    };
    if (!this.registry.system.collections.includes(collection)) {
      this.registry.system.collections.push(collection);
    }

    const registeredTokens = [];
    for (const tok of report.discoveredTokens || []) {
      const existing = this.registry.getAllTokens().find(token =>
        token.name.toLowerCase() === tok.name.toLowerCase()
      );
      if (existing) {
        registeredTokens.push(this.registry.updateToken(existing.id, {
          category: tok.category,
          type: tok.type || tok.category,
          value: tok.value,
          description: tok.description || '',
          collectionId: collection.id
        }));
      } else {
        registeredTokens.push(this.registry.addToken(tok.category, tok.name, tok.value, {
          collectionId: collection.id,
          description: tok.description
        }));
      }
    }

    const registeredComponents = [];
    for (const cmp of report.discoveredComponents || []) {
      const existing = this.registry.getAllComponents().find(component =>
        component.name.toLowerCase() === cmp.name.toLowerCase()
      );
      const updates = {
        category: cmp.category,
        properties: cmp.properties,
        sourceMetadata: cmp.sourceMetadata
      };
      const compDef = existing
        ? this.registry.updateComponent(existing.id, updates)
        : this.registry.registerComponent(cmp.name, updates);
      registeredComponents.push(compDef);
    }

    return {
      success: true,
      importedTokensCount: registeredTokens.length,
      importedComponentsCount: registeredComponents.length,
      collectionId: collection.id
    };
  }
}
